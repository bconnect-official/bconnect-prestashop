{*
*  Module made by Nukium
*
*  @author    Nukium
*  @copyright 2025 Nukium SAS
*  @license   All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*}
<div class="bconnect-btn-wrapper">
    {capture name='bconnect_separator'}
        <div class="bconnect-separator">
            <span>{l s='or' d='Modules.Bconnect.Shop'}</span>
        </div>
    {/capture}
    {assign var='bconnect_context' value=($bconnect_variant == 'create') ? 'create' : 'connect'}
    {if $bconnect_context == 'create'}
        {assign var='bconnect_text_alt' value={l s='Create with b.connect' d='Modules.Bconnect.Shop'}}
    {else}
        {assign var='bconnect_text_alt' value={l s='Sign in with b.connect' d='Modules.Bconnect.Shop'}}
        {$smarty.capture.bconnect_separator nofilter}
    {/if}
    {if $bconnect_display_slogan}
        <div class="bconnect-slogan">
            <p>
                {l s='Simplify and secure your logins with b.connect, the free, sovereign passwordless solution backed by France\'s largest banks.' d='Modules.Bconnect.Shop'}
                <br>
                <a
                    href="#"
                    class="bconnect-informations-link"
                    data-toggle="modal"
                    data-target="#bconnect-informations-modal"
                    data-bs-toggle="modal"
                    data-bs-target="#bconnect-informations-modal"
                >
                    {l s='Learn more' d='Modules.Bconnect.Shop'}
                </a>
            </p>
        </div>
    {/if}
    {assign var='bconnect_color' value=($bconnect_style == 'standard_white' || $bconnect_style == 'contextual_white') ? 'white' : 'blue'}
    {if empty($bconnect_force_variant) && $bconnect_style == 'icon'}
        {assign var='bconnect_img' value='bconnect_button.svg'}
        {assign var='bconnect_alt' value='b.connect'}
    {elseif empty($bconnect_force_variant) && ($bconnect_style == 'standard_blue' || $bconnect_style == 'standard_white')}
        {assign var='bconnect_img' value="bconnect_largebutton_{$bconnect_color}.svg"}
        {assign var='bconnect_alt' value='b.connect'}
    {else}
        {assign var='bconnect_img' value="bconnect_largebutton_{$bconnect_context}_{$bconnect_color}.svg"}
        {assign var='bconnect_alt' value=$bconnect_text_alt}
    {/if}
    <a
        href="{$bconnect_authorize_url|escape:'html':'UTF-8'}"
        class="bconnect-btn"
        aria-label="{$bconnect_alt|escape:'html':'UTF-8'}"
    >
        <img
            src="{$bconnect_module_dir}views/img/{$bconnect_img}"
            alt="{$bconnect_alt|escape:'html':'UTF-8'}"
            class="bconnect-btn__img"
            loading="lazy"
            decoding="async"
        />
    </a>
    {if $bconnect_context == 'create'}
        {$smarty.capture.bconnect_separator nofilter}
    {/if}
</div>
