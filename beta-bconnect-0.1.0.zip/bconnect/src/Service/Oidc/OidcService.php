<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Oidc;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use Firebase\JWT\JWK;
use Firebase\JWT\JWT;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use Nukium\Bconnect\Value\EnvironmentValue;
use Nukium\Bconnect\Value\ScopeValue;
use Symfony\Contracts\HttpClient\HttpClientInterface;
class OidcService
{
    const AUTHORIZE_URL_PRODUCTION = 'https://bconnect.net/a/oauth2/authorize';
    const TOKEN_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/access_token';
    const JWKS_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/connect/jwk_uri';
    const USERINFO_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/userinfo';
    const ISSUER_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect';
    const AUTHORIZE_URL_QUALIFICATION = 'https://bconnect-qualif.net/a/oauth2/authorize';
    const TOKEN_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/access_token';
    const JWKS_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/connect/jwk_uri';
    const USERINFO_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/userinfo';
    const ISSUER_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect';
    protected $configModuleHelper;
    protected $httpClient;
    public function __construct(
        ConfigModuleHelper $configModuleHelper,
        HttpClientInterface $httpClient
    ) {
        $this->configModuleHelper = $configModuleHelper;
        $this->httpClient = $httpClient;
    }
    public function buildAuthorizeUrl(string $state, string $nonce, string $redirectUri): string
    {
        $params = [
            'response_type' => 'code',
            'client_id' => $this->configModuleHelper->get(ConfigValue::CLIENT_ID),
            'redirect_uri' => $redirectUri,
            'scope' => $this->getScope(),
            'state' => $state,
            'nonce' => $nonce,
        ];
        $url = $this->isProduction() ? self::AUTHORIZE_URL_PRODUCTION : self::AUTHORIZE_URL_QUALIFICATION;
        return $url . '?' . http_build_query($params);
    }
    public function exchangeCode(string $code, string $redirectUri): array
    {
        $clientId = $this->configModuleHelper->get(ConfigValue::CLIENT_ID);
        $clientSecret = $this->configModuleHelper->get(ConfigValue::CLIENT_SECRET);
        $url = $this->isProduction() ? self::TOKEN_URL_PRODUCTION : self::TOKEN_URL_QUALIFICATION;
        $response = $this->httpClient->request('POST', $url, [
            'auth_basic' => [$clientId, $clientSecret],
            'body' => [
                'grant_type' => 'authorization_code',
                'code' => $code,
                'redirect_uri' => $redirectUri,
            ],
        ]);
        return $response->toArray();
    }
    public function validateIdToken(string $idToken, string $nonce): array
    {
        $jwks = $this->fetchJwks();
        $keys = JWK::parseKeySet($jwks);
        $allowedAlgorithms = ['RS256'];
        $decoded = JWT::decode($idToken, $keys, $allowedAlgorithms);
        $claims = (array) $decoded;
        $clientId = $this->configModuleHelper->get(ConfigValue::CLIENT_ID);
        if (empty($claims['sub'])) {
            throw new ModuleException('[bconnect] ID Token manquant : sub');
        }
        if (empty($claims['nonce']) || $claims['nonce'] !== $nonce) {
            throw new ModuleException('[bconnect] Nonce invalide');
        }
        $aud = $claims['aud'];
        $audMatches = \is_array($aud)
            ? \in_array($clientId, $aud, true)
            : $aud === $clientId;
        if (!$audMatches) {
            throw new ModuleException('[bconnect] Audience invalide');
        }
        $expectedIss = $this->isProduction() ? self::ISSUER_PRODUCTION : self::ISSUER_QUALIFICATION;
        if (!isset($claims['iss']) || $claims['iss'] !== $expectedIss) {
            throw new ModuleException('[bconnect] Issuer invalide');
        }
        return $claims;
    }
    public function fetchUserInfo(string $accessToken): array
    {
        $url = $this->isProduction() ? self::USERINFO_URL_PRODUCTION : self::USERINFO_URL_QUALIFICATION;
        $response = $this->httpClient->request('GET', $url, [
            'auth_bearer' => $accessToken,
            'timeout' => 5,
        ]);
        return $response->toArray();
    }
    protected function getScope(): string
    {
        $scopes = $this->configModuleHelper->get(ConfigValue::SCOPES);
        if (!is_array($scopes)) {
            $scopes = [];
        }
        $scopes = array_merge(ScopeValue::MANDATORY, $scopes);
        $scopes = array_values(array_intersect(ScopeValue::ALL, $scopes));
        return implode(' ', $scopes);
    }
    protected function isProduction(): bool
    {
        return $this->configModuleHelper->get(ConfigValue::ENVIRONMENT) === EnvironmentValue::PRODUCTION;
    }
    protected function fetchJwks(): array
    {
        $url = $this->isProduction() ? self::JWKS_URL_PRODUCTION : self::JWKS_URL_QUALIFICATION;
        $response = $this->httpClient->request('GET', $url);
        return $response->toArray();
    }
}
