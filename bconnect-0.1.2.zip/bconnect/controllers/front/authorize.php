<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Nukium\Bconnect\Service\Oidc\OidcService;
class BconnectAuthorizeModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $loggerHelper = null;
        try {
            $oidcService = $this->module->get('nukium.bconnect.service.oidc');
            $loggerHelper = $this->module->get('nukium.bconnect.helper.logger');
            if (
                !($oidcService instanceof OidcService) ||
                !($loggerHelper instanceof LoggerHelper)
            ) {
                throw new ModuleException('Impossible to retrieve services');
            }
            $state = bin2hex(random_bytes(32));
            $nonce = bin2hex(random_bytes(32));
            $action = Tools::getValue('action', 'login');
            if ($action === 'login' && Tools::getValue('origin') === 'checkout') {
                $action = 'checkout';
            }
            $this->context->cookie->bconnect_state = $state;
            $this->context->cookie->bconnect_nonce = $nonce;
            $this->context->cookie->bconnect_action = $action;
            $this->context->cookie->write();
            $redirectUri = $this->context->link->getModuleLink('bconnect', 'callback');
            $authorizeUrl = $oidcService->buildAuthorizeUrl($state, $nonce, $redirectUri);
            if (version_compare(_PS_VERSION_, '8.0.0', '>=')) {
                Tools::redirect($authorizeUrl);
            } else {
                Tools::redirectLink($authorizeUrl);
            }
        } catch (Exception $e) {
            if ($loggerHelper !== null) {
                $loggerHelper->error('[bconnect] Erreur authorize OIDC', [
                    'exception' => $e,
                ]);
            }
            $this->errors[] = $this->trans(
                'An error occurred while connecting with b.connect. Please try again.',
                [],
                'Modules.Bconnect.Shop'
            );
            $this->redirectWithNotifications(
                $this->context->link->getPageLink('authentication')
            );
        }
    }
}
