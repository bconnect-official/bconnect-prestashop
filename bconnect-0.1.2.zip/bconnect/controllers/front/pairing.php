<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Repository\CustomerMappingRepository;
class BconnectPairingModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        try {
            if (!$this->context->customer->isLogged()) {
                Tools::redirect($this->context->link->getPageLink('authentication'));
                return;
            }
            $action = Tools::getValue('action');
            if ($action === 'unlink') {
                $this->handleUnlink();
            } else {
                $this->handleLinkRedirect();
            }
        } catch (Exception $e) {
            $this->module->get('nukium.bconnect.helper.logger')->error(
                '[bconnect] Erreur pairing',
                ['exception' => $e]
            );
            Tools::redirect($this->context->link->getPageLink('my-account'));
        }
    }
    protected function handleUnlink(): void
    {
        if (!Tools::isSubmit('token') || Tools::getValue('token') !== $this->context->customer->secure_key) {
            $this->redirectWithError();
            return;
        }
        $repository = $this->module->get('nukium.bconnect.repository.customer_mapping');
        $repository->delete((int) $this->context->customer->id);
        Tools::redirect($this->context->link->getPageLink('my-account'));
    }
    protected function handleLinkRedirect(): void
    {
        Tools::redirect(
            $this->context->link->getModuleLink('bconnect', 'authorize') . '?action=pair'
        );
    }
    protected function redirectWithError(): void
    {
        Tools::redirect($this->context->link->getPageLink('my-account'));
    }
}
