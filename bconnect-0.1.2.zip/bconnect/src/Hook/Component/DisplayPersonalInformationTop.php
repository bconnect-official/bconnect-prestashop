<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Context;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use OrderController;
class DisplayPersonalInformationTop implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $module;
    public function __construct(
        Context $context,
        Bconnect $module
    ) {
        $this->context = $context;
        $this->module = $module;
    }
    public function callback(string $hookName, array $params): string
    {
        if (!($this->context->controller instanceof OrderController)) {
            return '';
        }
        return $this->module->displayHookSystem('checkout_personal_information_top.tpl');
    }
    public static function getHooks(): array
    {
        return [
            'displayPersonalInformationTop',
        ];
    }
}
