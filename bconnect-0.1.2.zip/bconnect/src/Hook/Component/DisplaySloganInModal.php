<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
class DisplaySloganInModal implements HookComponentInterface
{
    use HookComponentTrait;
    protected $module;
    protected $configModuleHelper;
    public function __construct(
        Bconnect $module,
        ConfigModuleHelper $configModuleHelper
    ) {
        $this->module = $module;
        $this->configModuleHelper = $configModuleHelper;
    }
    public function isAvailable(string $hookName, array $params): bool
    {
        return (bool) $this->configModuleHelper->get(ConfigValue::DISPLAY_SLOGAN);
    }
    public function callback(string $hookName, array $params): string
    {
        return $this->module->displayHookSystem('modal.tpl');
    }
    public static function getHooks(): array
    {
        return [
            'displayBeforeBodyClosingTag',
        ];
    }
}
