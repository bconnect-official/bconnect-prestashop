<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Context;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
class ActionFrontControllerSetMedia implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $module;
    public function __construct(
        Context $context,
        Bconnect $module
    ) {
        $this->context = $context;
        $this->module = $module;
    }
    public function callback(string $hookName, array $params): void
    {
        $this->context->controller->registerStylesheet(
            "module-{$this->module->name}-css-index",
            "modules/{$this->module->name}/views/dist/css/front-index.css",
            ['media' => 'all']
        );
        $this->context->controller->registerJavascript(
            "module-{$this->module->name}-js-checkout",
            "modules/{$this->module->name}/views/dist/js/front-checkout.js"
        );
    }
    public static function getHooks(): array
    {
        return [
            'actionFrontControllerSetMedia',
        ];
    }
}
