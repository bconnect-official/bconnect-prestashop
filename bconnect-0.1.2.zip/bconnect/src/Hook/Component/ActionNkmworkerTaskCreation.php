<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Service\Helper\TaskHelper;
use Nukium\Bconnect\Task\TaskAdapterInterface;
class ActionNkmworkerTaskCreation implements HookComponentInterface
{
    use HookComponentTrait;
    protected $taskHelper;
    protected $tasks;
    public function __construct(
        TaskHelper $taskHelper,
        iterable $tasks
    ) {
        $this->taskHelper = $taskHelper;
        $this->tasks = iterator_to_array($tasks);
    }
    public function callback(string $hookName, array $params): void
    {
        if (
            !isset($params['worker_tasks']) ||
            !is_array($params['worker_tasks'])
        ) {
            return;
        }
        $env = $this->taskHelper->getCommandEnv();
        foreach ($this->tasks as $task) {
            $extraOptions = $task->getExtraOptions();
            $extraOptionsParsed = [];
            foreach ($extraOptions as $key => $value) {
                $extraOptionsParsed[] = "{$key}={$value}";
            }
            $params['worker_tasks'][] = [
                'identifier' => $this->taskHelper->getIdentifier($task),
                'command_name' => $this->taskHelper->getCommandName($task),
                'description' => $task->getDescription(),
                'options' => [
                    'worker' => true,
                    'no-lock' => true,
                    'no-debug' => true,
                    'env' => $env,
                    'extra-option' => $extraOptionsParsed,
                ],
            ];
        }
    }
    public static function getHooks(): array
    {
        return [
            'actionNkmworkerTaskCreation',
        ];
    }
}
