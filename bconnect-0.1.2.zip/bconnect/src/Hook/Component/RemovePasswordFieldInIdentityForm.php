<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use FormField;
use IdentityController;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
use Validate;
class RemovePasswordFieldInIdentityForm implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $customerMappingRepository;
    public function __construct(
        Context $context,
        CustomerMappingRepository $customerMappingRepository
    ) {
        $this->context = $context;
        $this->customerMappingRepository = $customerMappingRepository;
    }
    public function isAvailable(string $hookName, array $params): bool
    {
        if (!($this->context->controller instanceof IdentityController)) {
            return false;
        }
        if (
            !Validate::isLoadedObject($this->context->customer) ||
            !$this->context->customer->isLogged()
        ) {
            return false;
        }
        $idCustomer = (int) $this->context->customer->id;
        $pairedCustomer = $this->customerMappingRepository->findByCustomerId($idCustomer);
        if ($pairedCustomer === null) {
            return false;
        }
        return true;
    }
    public function callback(string $hookName, array $params): void
    {
        if ($hookName === 'actionFrontControllerInitAfter') {
            $this->context->controller->passwordRequired = false;
        } elseif ($hookName === 'additionalCustomerFormFields') {
            if (
                !isset($params['fields']['new_password']) ||
                !($params['fields']['new_password'] instanceof FormField)
            ) {
                return;
            }
            $params['fields']['new_password']
                ->setType('hidden')
            ;
        }
    }
    public static function getHooks(): array
    {
        return [
            'actionFrontControllerInitAfter',
            'additionalCustomerFormFields',
        ];
    }
}
