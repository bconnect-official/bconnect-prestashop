<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Context;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
class DisplayCustomerAccount implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $module;
    protected $customerMappingRepository;
    public function __construct(
        Context $context,
        Bconnect $module,
        CustomerMappingRepository $customerMappingRepository
    ) {
        $this->context = $context;
        $this->module = $module;
        $this->customerMappingRepository = $customerMappingRepository;
    }
    public function isAvailable(string $hookName, array $params): bool
    {
        return $this->context->customer->isLogged();
    }
    public function callback(string $hookName, array $params): string
    {
        $idCustomer = (int) $this->context->customer->id;
        $isPaired = $this->customerMappingRepository->findByCustomerId($idCustomer) !== null;
        return $this->module->displayHookSystem('customer_account.tpl', [
            'bconnect_is_paired' => $isPaired,
            'bconnect_module_dir' => $this->module->getPathUri(),
            'bconnect_pair_url' => $this->context->link->getModuleLink('bconnect', 'pairing'),
            'bconnect_unlink_url' => $this->context->link->getModuleLink('bconnect', 'pairing') . '?action=unlink',
            'bconnect_token' => $this->context->customer->secure_key,
        ]);
    }
    public static function getHooks(): array
    {
        return [
            'displayCustomerAccount',
        ];
    }
}
