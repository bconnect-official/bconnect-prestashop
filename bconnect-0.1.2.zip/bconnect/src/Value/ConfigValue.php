<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Value;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigValue
{
    const CONFIG_PREFIX = 'BCONNECT_';
    const SECURE_KEY = 'SECURE_KEY';
    const PATCH = 'PATCH';
    const CLIENT_ID = 'CLIENT_ID';
    const CLIENT_SECRET = 'CLIENT_SECRET';
    const ENVIRONMENT = 'ENVIRONMENT';
    const SCOPES = 'SCOPES';
    const BUTTON_STYLE = 'BUTTON_STYLE';
    const DISPLAY_SLOGAN = 'DISPLAY_SLOGAN';
    const DEBUG_MODE = 'DEBUG_MODE';
    const ALL = [
        self::SECURE_KEY => [
            'is_all_shop' => true,
        ],
        self::PATCH => [
            'is_all_shop' => true,
            'init' => [],
        ],
        self::CLIENT_ID => [
            'init' => '',
        ],
        self::CLIENT_SECRET => [
            'init' => '',
        ],
        self::ENVIRONMENT => [
            'init' => EnvironmentValue::PRODUCTION,
        ],
        self::SCOPES => [
            'init' => ScopeValue::ALL,
        ],
        self::BUTTON_STYLE => [
            'init' => ButtonValue::STYLE_ICON,
        ],
        self::DISPLAY_SLOGAN => [
            'init' => true,
        ],
        self::DEBUG_MODE => [
            'is_all_shop' => true,
            'init' => false,
        ],
    ];
}
