<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Value;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ScopeValue
{
    const OPENID = 'openid';
    const EMAIL = 'email';
    const GIVEN_NAME = 'given_name';
    const FAMILY_NAME = 'family_name';
    const POSTALADDRESS = 'postaladdress';
    const PHONE = 'phone';
    const BIRTHDATE = 'birthdate';
    const CIVILITY = 'civility';
    const MANDATORY = [
        self::OPENID,
        self::EMAIL,
    ];
    const ALL = [
        self::OPENID,
        self::EMAIL,
        self::GIVEN_NAME,
        self::FAMILY_NAME,
        self::POSTALADDRESS,
        self::PHONE,
    ];
}
