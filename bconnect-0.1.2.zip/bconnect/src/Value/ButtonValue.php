<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Value;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ButtonValue
{
    const STYLE_ICON = 'icon';
    const STYLE_STANDARD_BLUE = 'standard_blue';
    const STYLE_STANDARD_WHITE = 'standard_white';
    const STYLE_CONTEXTUAL_BLUE = 'contextual_blue';
    const STYLE_CONTEXTUAL_WHITE = 'contextual_white';
    const STYLE_PREVIEW_IMAGES = [
        self::STYLE_ICON => 'bconnect_button.svg',
        self::STYLE_STANDARD_BLUE => 'bconnect_largebutton_blue.svg',
        self::STYLE_STANDARD_WHITE => 'bconnect_largebutton_white.svg',
        self::STYLE_CONTEXTUAL_BLUE => 'bconnect_largebutton_connect_blue.svg',
        self::STYLE_CONTEXTUAL_WHITE => 'bconnect_largebutton_connect_white.svg',
    ];
}
