<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Task\Processor;

if (!defined('_PS_VERSION_')) {
    exit;
}

use ArrayObject;
use Nukium\Bconnect\Exception\LogicException;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\FileHelper;
use Nukium\Bconnect\Task\TaskAdapterInterface;
use Nukium\Bconnect\Task\LongTaskAdapterInterface;
use Nukium\Bconnect\Value\LongTaskValue;
use Throwable;
class LongTaskProcessor implements TaskAdapterInterface
{
    protected $fileHelper;
    protected $longTaskAdapter;
    public function __construct(
        FileHelper $fileHelper,
        LongTaskAdapterInterface $longTaskAdapter
    ) {
        $this->fileHelper = $fileHelper;
        $this->longTaskAdapter = $longTaskAdapter;
    }
    public function callbackRun(array $options = []): void
    {
        if (!isset($options['debug'])) {
            $options['debug'] = false;
        }
        if (!isset($options['process_id'])) {
            $options['process_id'] = null;
        }
        $store = $this->getStore($options);
        $options['store'] = $store;
        $updateStore = true;
        try {
            $step = $store['step'];
            $processId = $store['process_id'];
            if ($options['process_id'] !== $processId) {
                throw new ModuleException(
                    'Une autre tâche a été lancée. Celle-ci a donc été annulée.'
                );
            }
            $this->longTaskAdapter->log('[START PACK]');
            switch ($step) {
                case LongTaskValue::STEP_INIT:
                    $this->longTaskAdapter->callbackInit($options);
                    $store['step'] = LongTaskValue::STEP_RUN;
                    break;
                case LongTaskValue::STEP_RUN:
                    $this->longTaskAdapter->callbackRun($options);
                    break;
                case LongTaskValue::STEP_FINISHING:
                    $this->longTaskAdapter->callbackFinish($options);
                    $store['step'] = LongTaskValue::STEP_FINISHED;
                    break;
                case LongTaskValue::STEP_FINISHED:
                    $this->resetStore();
                    $updateStore = false;
                    break;
                default:
                    throw new LogicException(sprintf(
                        'Unknown step "%s".',
                        $step
                    ));
            }
            $this->longTaskAdapter->log('[END PACK]');
        } catch (Throwable $e) {
            $this->longTaskAdapter->log('[ERROR PACK]', [
                'exception' => $e,
            ]);
            if ($options['debug']) {
                dump($e);
            }
            $store['step'] = LongTaskValue::STEP_ERROR;
            throw $e;
        } finally {
            if ($updateStore) {
                $this->updateStore($store);
            }
        }
    }
    public function init(): void
    {
        $this->longTaskAdapter->init();
    }
    public function getEmployeeMode(): int
    {
        return $this->longTaskAdapter->getEmployeeMode();
    }
    public function getTaskName(): string
    {
        return $this->longTaskAdapter->getTaskName();
    }
    public function getDescription(): string
    {
        return $this->longTaskAdapter->getDescription();
    }
    public function getExtraOptions(): array
    {
        return $this->longTaskAdapter->getExtraOptions();
    }
    public function isEnabled(): bool
    {
        return $this->longTaskAdapter->isEnabled();
    }
    public function log(string $message, array $context = []): void
    {
        $this->longTaskAdapter->log($message, $context);
    }
    public function hasStore(): bool
    {
        $storeFilename = $this->getStoreFilename();
        return $this->fileHelper->exists($storeFilename);
    }
    public function getStore(array $options = []): ArrayObject
    {
        if (!isset($options['process_id'])) {
            $options['process_id'] = null;
        }
        $storeFilename = $this->getStoreFilename();
        if (!$this->hasStore()) {
            $store = new ArrayObject([
                'step' => LongTaskValue::STEP_INIT,
                'process_id' => $options['process_id'],
            ]);
        } else {
            $storeData = $this->fileHelper->read($storeFilename);
            $storeData = unserialize($storeData);
            $store = new ArrayObject($storeData);
        }
        return $store;
    }
    public function updateStore(ArrayObject $store): void
    {
        $storeFilename = $this->getStoreFilename();
        $this->fileHelper->write(
            $storeFilename,
            serialize($store->getArrayCopy())
        );
    }
    public function resetStore(): void
    {
        $storeFilename = $this->getStoreFilename();
        if (!$this->hasStore()) {
            return;
        }
        $this->fileHelper->delete($storeFilename);
    }
    public function isFinished(array $options = []): bool
    {
        if (!isset($options['process_id'])) {
            $options['process_id'] = null;
        }
        if (!$this->hasStore()) {
            return true;
        }
        $store = $this->getStore($options);
        if ($options['process_id'] !== null) {
            return ($store['process_id'] !== $options['process_id']);
        }
        return ($store['step'] === LongTaskValue::STEP_FINISHED);
    }
    protected function getStoreFilename(): string
    {
        $taskName = $this->longTaskAdapter->getTaskName();
        return "/long-task/{$taskName}.data";
    }
}
