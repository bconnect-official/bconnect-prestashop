<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Task\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Nukium\Bconnect\Task\TaskAdapterInterface;
use Nukium\Bconnect\Value\CommandEmployeeValue;
abstract class AbstractTaskAdapter implements TaskAdapterInterface
{
    protected $loggerHelper;
    public function __construct(
        LoggerHelper $loggerHelper
    ) {
        $this->loggerHelper = $loggerHelper;
    }
    public function init(): void
    {
        $this->setTimeLimit();
        $this->increaseMemoryLimit();
    }
    public function getDescription(): string
    {
        return '';
    }
    public function getExtraOptions(): array
    {
        return [];
    }
    public function getEmployeeMode(): int
    {
        return CommandEmployeeValue::EMPLOYEE_MODE_NO_EMPLOYEE;
    }
    public function log(string $message, array $context = []): void
    {
        $message = $this->getLogMessage($message);
        $type = $this->getTaskName();
        $context = $this->getLogContext($context);
        $this->loggerHelper->log($message, $type, $context);
    }
    protected function getLogMessage(string $message): string
    {
        return "[TASK] {$message}";
    }
    protected function getLogContext(array $context): array
    {
        return $context;
    }
    protected function setTimeLimit(): void
    {
        set_time_limit(0);
    }
    protected function getMemoryLimit(): int
    {
        return 2048;
    }
    protected function increaseMemoryLimit(): void
    {
        $memory = $this->getMemoryLimit();
        $currentMemoryLimit = (int) ini_get('memory_limit');
        if ($currentMemoryLimit >= $memory) {
            return;
        }
        ini_set('memory_limit', "{$memory}M");
    }
}
