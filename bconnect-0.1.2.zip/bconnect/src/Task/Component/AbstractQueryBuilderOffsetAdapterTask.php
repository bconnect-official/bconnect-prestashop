<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Task\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Query\QueryBuilder;
use Exception;
use Nukium\Bconnect\Value\LongTaskValue;
abstract class AbstractQueryBuilderOffsetAdapterTask extends AbstractLongTaskAdapter
{
    const LIMIT = 100;
    public function callbackInit(array $options = []): void
    {
        $options['store']['count'] = $this->count();
        $options['store']['offset'] = 0;
        if (
            !isset($options['store']['limit']) ||
            isset($options['limit'])
        ) {
            $options['store']['limit'] = $options['limit'] ?? self::LIMIT;
        }
    }
    public function callbackRun(array $options = []): void
    {
        $data = $this->getQueryBuilder($options)
            ->setMaxResults($options['store']['limit'])
            ->setFirstResult($options['store']['offset'])
            ->execute()
            ->fetchAll()
        ;
        foreach ($data as $i => $element) {
            $cursor = $i + $options['store']['offset'];
            try {
                $this->callbackOffset($cursor, $element, $options);
            } catch (Exception $e) {
                $this->log('ERROR OFFSET', [
                    'exception' => $e,
                ]);
            }
        }
        $options['store']['offset'] += count($data);
        if ($options['store']['offset'] >= $options['store']['count']) {
            $options['store']['step'] = LongTaskValue::STEP_FINISHING;
        }
    }
    protected function count(): int
    {
        $result = $this->getQueryBuilder()
            ->select('COUNT(*)')
            ->execute()
        ;
        if (method_exists($result, 'fetchOne')) {
            $result = $result->fetchOne();
        } else {
            $result = $result->fetchColumn();
        }
        return (int) $result;
    }
    abstract protected function getQueryBuilder(array $options = []): QueryBuilder;
    abstract protected function callbackOffset(
        int $cursor,
        array $element,
        array $options
    ): void;
}
