<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Patch\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Db;
use Nukium\Bconnect\Patch\PatchComponentInterface;
class CreateTablePatch implements PatchComponentInterface
{
    public function install(Bconnect $module): void
    {
        Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'bconnect_customer` (
                `id_bconnect_customer` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_customer`          INT UNSIGNED NOT NULL,
                `sub`                  VARCHAR(255) NOT NULL,
                `date_add`             DATETIME NOT NULL,
                PRIMARY KEY (`id_bconnect_customer`),
                UNIQUE KEY `uk_id_customer` (`id_customer`),
                UNIQUE KEY `uk_sub` (`sub`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;'
        );
    }
    public function uninstall(Bconnect $module): void
    {
        Db::getInstance()->execute(
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'bconnect_customer`'
        );
    }
    public function isAlwaysExecuted(): bool
    {
        return false;
    }
}
