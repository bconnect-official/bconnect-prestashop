<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Patch\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\HookSystem;
use Nukium\Bconnect\Patch\PatchComponentInterface;
use Bconnect;
use ReflectionClass;
use Symfony\Component\Finder\Finder;
class RegisterHookPatch implements PatchComponentInterface
{
    public function install(Bconnect $module): void
    {
        $hookSystemFullClass = HookSystem::class;
        $hookSystemReflector = new ReflectionClass($hookSystemFullClass);
        $hookSystemNamespace = $hookSystemReflector->getNamespaceName();
        $hookSystemPath = $hookSystemReflector->getFileName();
        $hookSystemDir = dirname($hookSystemPath);
        $finder = (new Finder())
            ->in("{$hookSystemDir}/Component")
            ->files()
            ->name('*.php')
            ->notName('index.php')
        ;
        foreach ($finder as $file) {
            $componentClass = $file->getBasename('.php');
            $componentPath = $file->getRealPath();
            $componentDir = dirname($componentPath);
            $componentRelativeDir = str_replace($hookSystemDir, '', $componentDir);
            $componentNamespace = str_replace('/', '\\', $componentRelativeDir);
            $componentNamespace = trim($componentNamespace, '\\');
            $componentNamespace = "{$hookSystemNamespace}\\{$componentNamespace}";
            $componentFullClass = "{$componentNamespace}\\{$componentClass}";
            $reflection = new ReflectionClass($componentFullClass);
            if (
                !class_exists($componentFullClass) ||
                !is_a($componentFullClass, HookComponentInterface::class, true) ||
                $reflection->isAbstract() ||
                !$reflection->isInstantiable()
            ) {
                continue;
            }
            $hooks = $componentFullClass::getHooks();
            foreach ($hooks as $hookName) {
                $module->registerHook($hookName);
            }
        }
    }
    public function uninstall(Bconnect $module): void
    {
    }
    public function isAlwaysExecuted(): bool
    {
        return true;
    }
}
