<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Patch;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use Bconnect;
class PatchSystem
{
    protected $module;
    protected $configModuleHelper;
    protected $patches;
    public function __construct(
        Bconnect $module,
        ConfigModuleHelper $configModuleHelper,
        iterable $patches
    ) {
        $this->module = $module;
        $this->configModuleHelper = $configModuleHelper;
        $this->patches = iterator_to_array($patches);
    }
    public function install(): void
    {
        $registeredPatches = $this->configModuleHelper->get(
            ConfigValue::PATCH
        );
        foreach ($this->patches as $patch) {
            $patchName = get_class($patch);
            $isAlwaysExecuted = $patch->isAlwaysExecuted();
            if (
                !$isAlwaysExecuted &&
                in_array($patchName, $registeredPatches, true)
            ) {
                continue;
            }
            $patch->install($this->module);
            if (!$isAlwaysExecuted) {
                $registeredPatches[] = $patchName;
            }
            $this->configModuleHelper->update(
                ConfigValue::PATCH,
                $registeredPatches
            );
        }
    }
    public function uninstall(): void
    {
        $registeredPatches = $this->configModuleHelper->get(
            ConfigValue::PATCH
        );
        foreach (array_reverse($this->patches) as $patch) {
            $patchName = get_class($patch);
            $patchIndex = array_search(
                $patchName,
                $registeredPatches,
                true
            );
            if (
                $patchIndex === false &&
                !$patch->isAlwaysExecuted()
            ) {
                continue;
            }
            $patch->uninstall($this->module);
            unset($registeredPatches[$patchIndex]);
            $registeredPatches = array_values($registeredPatches);
            $this->configModuleHelper->update(
                ConfigValue::PATCH,
                $registeredPatches
            );
        }
        $configs = ConfigValue::ALL;
        $configs = array_keys($configs);
        $this->configModuleHelper->deleteAll($configs);
    }
}
