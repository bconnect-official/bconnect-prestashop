<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Command;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Hook;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Task\Processor\LongTaskProcessor;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
class LongTaskCommand extends TaskCommand
{
    const ERROR_MESSAGES = [
        'php fatal error',
        'Error thrown',
    ];
    protected function configure(): void
    {
        parent::configure();
        $this->addOption(
            'task-continue',
            null,
            InputOption::VALUE_NONE,
            ''
        );
        $this->addOption(
            'worker',
            null,
            InputOption::VALUE_NONE,
            ''
        );
        $this->addOption(
            'process-id',
            null,
            InputOption::VALUE_OPTIONAL,
            '',
            ''
        );
    }
    protected function callback(
        array $extraOptions,
        InputInterface $input,
        OutputInterface $output
    ): int {
        if (!($this->taskAdapter instanceof LongTaskProcessor)) {
            throw new ModuleException(
                'The task adapter must be an instance of LongTaskProcessor'
            );
        }
        $taskContinue = (bool) $input->getOption('task-continue');
        $worker = (bool) $input->getOption('worker');
        $processId = (string) $input->getOption('process-id');
        if (empty($processId)) {
            $processId = random_bytes(8);
            $processId = bin2hex($processId);
            $input->setOption(
                'process-id',
                $processId
            );
        }
        $extraOptions['process_id'] = $processId;
        if (!$taskContinue) {
            $this->taskAdapter->resetStore();
        }
        if (
            !$taskContinue &&
            !$worker
        ) {
            $this->executeGlobal(
                $extraOptions,
                $input,
                $output
            );
        } else {
            $this->executeChild(
                $extraOptions,
                $input,
                $output
            );
            if ($worker) {
                if (!$this->taskAdapter->isFinished($extraOptions)) {
                    Hook::exec('actionNkmworkerCreateProcess', [
                        'identifier' => $this->taskHelper->getIdentifier(
                            $this->taskAdapter
                        ),
                        'options' => [
                            'enable_double' => true,
                            'task_options' => [
                                'process-id' => $processId,
                                'task-continue' => true,
                            ],
                        ],
                    ]);
                }
            }
        }
        return 0; 
    }
    protected function executeGlobal(
        array $extraOptions,
        InputInterface $input,
        OutputInterface $output
    ): void {
        $count = 1;
        $output->writeln('------');
        $output->writeln('Début');
        do {
            $this->fork($count, $input, $output);
            ++$count;
        } while (!$this->taskAdapter->isFinished($extraOptions));
        $output->writeln('------');
        $output->writeln('Fin');
        $output->writeln('------');
    }
    protected function executeChild(
        array $extraOptions,
        InputInterface $input,
        OutputInterface $output
    ): void {
        $this->log('[START CHILD]');
        $timeA = microtime(true);
        $this->taskAdapter->callbackRun($extraOptions);
        $timeB = microtime(true);
        $executedTime = round($timeB - $timeA, 4);
        $memoryMax = memory_get_peak_usage(true);
        $memoryMax = $memoryMax / 1024 / 1024;
        $output->writeln("Process enfant terminé | Temps : {$executedTime} secondes | Mémoire : {$memoryMax} MB");
        $this->log('[END CHILD]');
    }
    protected function fork(
        int $count,
        InputInterface $input,
        OutputInterface $output
    ): int {
        $commandName = $this->getCommandName();
        $consolePath = PHP_BINARY . ' -f ' . _PS_ROOT_DIR_ . '/bin/console';
        $taskOptions = $input->getOptions();
        $taskOptions['task-continue'] = true;
        $taskOptions['no-lock'] = true;
        $commandOptions = '';
        foreach ($taskOptions as $name => $allValues) {
            if (!is_array($allValues)) {
                $allValues = [$allValues];
            }
            foreach ($allValues as $value) {
                if (is_bool($value)) {
                    if ($value) {
                        $commandOptions .= " --{$name}";
                    }
                } else {
                    if (!is_scalar($value)) {
                        continue;
                    }
                    $value = (string) $value;
                    $value = escapeshellarg($value);
                    $commandOptions .= " --{$name}={$value}";
                }
            }
        }
        $output->writeln('------');
        $output->writeln("Éxécution du process enfant N°{$count}...");
        $result = $this->execCommand("{$consolePath} {$commandName}{$commandOptions}");
        $this->handleChildOutput($result, $output);
        return $result['exitCode'];
    }
    protected function execCommand(string $command): array
    {
        $pipes = null;
        $descriptors = [
            0 => ['pipe', 'r'], 
            1 => ['pipe', 'w'], 
            2 => ['pipe', 'w'], 
        ];
        $process = proc_open($command, $descriptors, $pipes);
        if (!is_resource($process)) {
            throw new ModuleException(
                "The command \"{$command}\" failed !"
            );
        }
        fclose($pipes[0]);
        $output = stream_get_contents($pipes[1]);
        $error = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exitCode = proc_close($process);
        return [
            'output' => trim($output),
            'error' => trim($error),
            'exitCode' => $exitCode,
        ];
    }
    protected function handleChildOutput(
        array $result,
        OutputInterface $output
    ): void {
        if (!empty($result['output'])) {
            $output->writeln($result['output']);
        }
        if (!empty($result['error'])) {
            $output->writeln($result['error']);
            $errorLower = strtolower($result['error']);
            foreach (self::ERROR_MESSAGES as $message) {
                $messageLower = strtolower($message);
                if (strpos($errorLower, $messageLower) !== false) {
                    throw new ModuleException(
                        'The child process has failed because of PHP fatal error !'
                    );
                }
            }
        }
    }
}
