<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Command;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Cart;
use Configuration;
use Context;
use Country;
use Currency;
use Db;
use Employee;
use Hook;
use Language;
use Nukium\Bconnect\Exception\LogicException;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\SemaphoreHelper;
use Nukium\Bconnect\Service\Helper\TaskHelper;
use Nukium\Bconnect\Task\LongTaskAdapterInterface;
use Nukium\Bconnect\Task\Processor\LongTaskProcessor;
use Nukium\Bconnect\Task\TaskAdapterInterface;
use Nukium\Bconnect\Value\CommandEmployeeValue;
use PrestaShop\PrestaShop\Core\Localization\Locale\Repository as LocaleRepository;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Exception\RuntimeException;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Throwable;
use Tools;
use Validate;
use Bconnect;
class TaskCommand extends Command
{
    protected $context;
    protected $db;
    protected $module;
    protected $localeRepository;
    protected $semaphoreHelper;
    protected $taskHelper;
    protected $taskAdapter;
    public function __construct(
        Context $context,
        Db $db,
        Bconnect $module,
        LocaleRepository $localeRepository,
        SemaphoreHelper $semaphoreHelper,
        TaskHelper $taskHelper,
        TaskAdapterInterface $taskAdapter
    ) {
        $this->context = $context;
        $this->db = $db;
        $this->module = $module;
        $this->localeRepository = $localeRepository;
        $this->semaphoreHelper = $semaphoreHelper;
        $this->taskHelper = $taskHelper;
        $this->taskAdapter = $taskAdapter;
        parent::__construct();
    }
    protected function configure(): void
    {
        $commandName = $this->getCommandName();
        $this->setName($commandName);
        $this->addOption(
            'id_lang',
            null,
            InputOption::VALUE_OPTIONAL,
            'Permet de définir l\'ID de la langue à utiliser pour le contexte. Si cette option n\'est pas définie, la langue par défaut du module sera utilisée.',
            null
        );
        $this->addOption(
            'locale',
            null,
            InputOption::VALUE_OPTIONAL,
            'Permet de définir la locale à utiliser pour le contexte (langue et country). Le format attendu est "langue-pays" (par exemple, "fr-FR").',
            null
        );
        $this->addOption(
            'no-lock',
            null,
            InputOption::VALUE_NONE,
            'Permet de désactiver le verrouillage de la tâche.'
        );
        $this->addOption(
            'release-lock',
            null,
            InputOption::VALUE_NONE,
            'Permet de libérer le verrouillage de la tâche précédente.'
        );
        $this->addOption(
            'extra-option',
            null,
            InputOption::VALUE_OPTIONAL | InputOption::VALUE_IS_ARRAY,
            'Saisir les options sous la forme "--options option1=valeur1 --options option2=valeur2". Si une option n\'a pas de valeur, utilisez simplement "--options boolean_option" pour l\'activer.'
        );
    }
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->log('[GLOBAL START]');
        $noLock = (bool) $input->getOption('no-lock');
        $releaseLock = (bool) $input->getOption('release-lock');
        $extraOptions = $this->getExtraOptions($input);
        $taskName = $this->taskAdapter->getTaskName();
        try {
            $this->taskAdapter->init();
            $this->initContext($input, $output);
            if (!($this instanceof LongTaskCommand)) {
                if ($this->taskAdapter instanceof LongTaskAdapterInterface) {
                    throw new LogicException(
                        'The task adapter cannot not be LongTaskAdapterInterface for a simple task.'
                    );
                }
                if ($this->taskAdapter instanceof LongTaskProcessor) {
                    throw new LogicException(
                        'To use LongTaskProcessor as task adapter, you must use LongTaskCommand instead of TaskCommand.'
                    );
                }
            }
            if (!$this->taskAdapter->isEnabled()) {
                throw new ModuleException(
                    'Command is disabled'
                );
            }
            if (!$noLock) {
                $lock = $this->semaphoreHelper->createLock($taskName);
                if ($releaseLock) {
                    $lock->release();
                }
                if (!$lock->acquire(false)) {
                    throw new ModuleException(
                        "The task is already running (lock name: {$taskName})."
                    );
                }
            }
            return $this->callback(
                $extraOptions,
                $input,
                $output
            );
        } catch (Throwable $e) {
            $errorMessage = $e->getMessage();
            $this->log("[GLOBAL ERROR] {$errorMessage}", [
                'exception' => $e,
            ]);
            throw new RuntimeException($errorMessage);
        } finally {
            $this->log('[GLOBAL END]');
        }
    }
    protected function callback(
        array $extraOptions,
        InputInterface $input,
        OutputInterface $output
    ): int {
        $output->writeln('Tâche en cours d\'exécution...');
        $this->taskAdapter->callbackRun($extraOptions);
        $output->writeln('Fin');
        return 0; 
    }
    protected function log(string $message, array $context = []): void
    {
        $this->taskAdapter->log($message, $context);
    }
    protected function initContext(
        InputInterface $input,
        OutputInterface $output
    ): void {
        $commandName = $this->getCommandName();
        $idLang = (int) Configuration::get('PS_LANG_DEFAULT');
        $idCountry = (int) Configuration::get('PS_COUNTRY_DEFAULT');
        $idLang = (int) ($input->getOption('id_lang') ?? $idLang);
        $locale = $input->getOption('locale');
        if (!empty($locale)) {
            $locale = str_replace('_', '-', $locale);
            $locale = strtolower($locale);
            $tempLocale = explode('-', $locale, 2);
            if (count($tempLocale) !== 2) {
                throw new ModuleException(
                    'Invalid "locale" argument format. Expected format: "language-country" (e.g., "en-US").'
                );
            }
            $langIso = $tempLocale[0];
            $countryIso = $tempLocale[1];
            $idLang = Language::getIdByIso($langIso);
            $idCountry = Country::getByIso($countryIso);
            if (!is_int($idLang) || $idLang <= 0) {
                throw new ModuleException(
                    "Language with ISO code {$langIso} does not exist."
                );
            }
            if (!is_int($idCountry) || $idCountry <= 0) {
                throw new ModuleException(
                    "Country with ISO code {$countryIso} does not exist."
                );
            }
        }
        $language = new Language($idLang);
        $country = new Country($idCountry);
        if (!Validate::isLoadedObject($language)) {
            throw new ModuleException(
                "Language with ID {$idLang} does not exist."
            );
        }
        if (!Validate::isLoadedObject($country)) {
            throw new ModuleException(
                "Country with ID {$idCountry} does not exist."
            );
        }
        if (empty($locale)) {
            $locale = $language->getLocale();
        }
        $this->setContextEmployee();
        $this->context->language = $language;
        $this->context->country = $country;
        $this->context->currentLocale = $this->localeRepository->getLocale($locale);
        $this->context->cart = new Cart();
        $this->context->cart->id_lang = (int) $this->context->language->id;
        $this->context->cart->id_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');
        $this->context->cart->id_shop_group = (int) $this->context->shop->id_shop_group;
        $this->context->cart->id_shop = (int) $this->context->shop->id;
        $this->context->cart->id_guest = 0;
        $this->context->cart->id_customer = 0;
        $this->context->cart->id_address_delivery = 0;
        $this->context->cart->id_address_invoice = 0;
        $this->context->currency = Currency::getCurrencyInstance(
            (int) Configuration::get('PS_CURRENCY_DEFAULT')
        );
        $this->context->cookie->id_currency = (int) $this->context->currency->id;
        $this->context->cookie->id_lang = (int) $this->context->language->id;
        $this->context->cookie->id_customer = 0;
        $this->context->cookie->id_guest = 0;
        $this->context->cookie->logged = 0;
        Hook::exec('actionAfterInitNkmCommand', [
            'command_name' => $commandName,
            'input' => $input,
            'output' => $output,
        ]);
    }
    protected function setContextEmployee(): void
    {
        $moduleName = $this->module->name;
        $email = str_replace(
            '{module_name}',
            $moduleName,
            CommandEmployeeValue::EMPLOYEE_EMAIL
        );
        switch ($this->taskAdapter->getEmployeeMode()) {
            case CommandEmployeeValue::EMPLOYEE_MODE_EMPTY_EMPLOYEE:
                $employee = new Employee();
                $employee->id = 0;
                break;
            case CommandEmployeeValue::EMPLOYEE_MODE_REAL_EMPLOYEE:
                $row = $this->db->getRow('
                    SELECT *
                    FROM ' . _DB_PREFIX_ . 'employee
                    WHERE email = "' . pSQL($email) . '"
                ');
                if (is_array($row)) {
                    $employee = new Employee((int) $row['id_employee']);
                } else {
                    $plaintextPassword = Tools::passwdGen(16);
                    $employee = new Employee();
                    $employee->id_profile = _PS_ADMIN_PROFILE_;
                    $employee->firstname = "CLI {$moduleName}";
                    $employee->lastname = 'Nukium';
                    $employee->email = $email;
                    $employee->setWsPasswd($plaintextPassword);
                    $employee->bo_theme = 'default';
                    $employee->default_tab = 1;
                    $employee->active = false;
                    $employee->bo_menu = true;
                    $employee->id_lang = (int) Configuration::get('PS_LANG_DEFAULT');
                    $employee->add();
                }
                break;
            default:
                $employee = null;
                break;
        }
        if ($employee === null) {
            return;
        }
        $this->context->employee = $employee;
    }
    protected function getCommandName(): string
    {
        return $this->taskHelper->getCommandName($this->taskAdapter);
    }
    protected function getExtraOptions(InputInterface $input): array
    {
        $result = [];
        $extraOptions = $input->getOption('extra-option');
        if (!is_array($extraOptions)) {
            $extraOptions = [];
        }
        foreach ($extraOptions as $value) {
            $tmp = explode('=', $value, 2);
            if (count($tmp) === 2) {
                $result[$tmp[0]] = $tmp[1];
            } else {
                $result[$tmp[0]] = true;
            }
        }
        return $result;
    }
}
