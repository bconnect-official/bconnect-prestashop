<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use ModuleFrontController;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Nukium\Bconnect\Service\Helper\SemaphoreHelper;
use Nukium\Bconnect\Value\ConfigValue;
use Tools;
abstract class CronHelper extends ModuleFrontController
{
    const DEFAULT_ERROR_STATUS = 500;
    const HTTP_STATUS = [
        200,
        400,
        403,
        404,
        500,
    ];
    public function postProcess()
    {
        $this->setTimeLimit();
        $configModuleHelper = $this->get('nukium.bconnect.helper.config_module');
        $semaphoreHelper = $this->get('nukium.bconnect.helper.semaphore');
        $output = null;
        $secureKey = $configModuleHelper->get(ConfigValue::SECURE_KEY);
        $taskName = $this->getTaskName();
        $lock = null;
        $hasTaskLocker = (bool) Tools::getValue('has_task_locker', false);
        try {
            if (Tools::getValue('secure_key', null) !== $secureKey) {
                throw new ModuleException($this->trans(
                    'Secure Key invalid',
                    [],
                    'Modules.Bconnect.Front'
                ), 403);
            }
            if ((int) Tools::getValue('ajax', 0) !== 1) {
                throw new ModuleException($this->trans(
                    'Cron must be executed in ajax mode',
                    [],
                    'Modules.Bconnect.Front'
                ), 403);
            }
            if (
                !$this->module->active ||
                !$this->isEnabled()
            ) {
                throw new ModuleException($this->trans(
                    'Cron disabled',
                    [],
                    'Modules.Bconnect.Front'
                ), 404);
            }
            if ($hasTaskLocker) {
                $lock = $semaphoreHelper->createLock($taskName);
                if ((int) Tools::getValue('release_lock', 0) === 1) {
                    $lock->release();
                }
                if (!$lock->acquire(false)) {
                    throw new ModuleException($this->trans(
                        'This task is already running. Please wait few moments before restarting.',
                        [],
                        'Modules.Bconnect.Front'
                    ), 409);
                }
            }
            $this->log("[{$taskName}] START");
            $this->cronCallback();
            $this->log("[{$taskName}] END");
        } catch (Exception $e) {
            $output = $e->getMessage();
            $httpStatus = (int) $e->getCode();
            if (empty($output)) {
                $output = $this->trans(
                    'An error has occured',
                    [],
                    'Modules.Bconnect.Common'
                );
            }
            if (
                !($e instanceof ModuleException) ||
                !in_array($httpStatus, self::HTTP_STATUS, true)
            ) {
                $httpStatus = self::DEFAULT_ERROR_STATUS;
            }
            if (
                $e instanceof ModuleException &&
                $e->getCode() === 409
            ) {
                $hasTaskLocker = false;
            }
            http_response_code($httpStatus);
            $this->log($output, [
                'exception' => $e,
            ]);
            if ((int) Tools::getValue('nkmdebug', 0) === 1) {
                dump($e->getTrace());
            }
        }
        if (
            $hasTaskLocker &&
            $lock !== null
        ) {
            $lock->release();
        }
        if (empty($output)) {
            $output = 'OK';
        }
        $this->ajaxRender($output);
    }
    public function display()
    {
        return null;
    }
    public function displayAjax()
    {
        return null;
    }
    protected function getTaskName(): string
    {
        return strtolower(get_class($this));
    }
    protected function log(string $message, array $context = []): void
    {
        $loggerHelper = $this->get('nukium.bconnect.helper.logger');
        $taskName = $this->getTaskName();
        $loggerHelper->log($message, $taskName, $context);
    }
    protected function setTimeLimit(): void
    {
        set_time_limit(0);
    }
    abstract protected function cronCallback(): void;
    abstract protected function isEnabled(): bool;
}
