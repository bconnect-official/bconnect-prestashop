<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use Module;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Hook\HookSystem;
use Nukium\Bconnect\Patch\PatchSystem;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Bconnect;
use ReflectionClass;
use Shop;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;
use Throwable;
use Tools;
class ModuleHelper extends Module
{
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        return
            parent::install() &&
            $this->launchPatch(true)
        ;
    }
    public function uninstall()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        return
            $this->launchPatch(false) &&
            parent::uninstall()
        ;
    }
    public function isUsingNewTranslationSystem()
    {
        return true;
    }
    public function getContent()
    {
        $originalContext = Shop::getContext();
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        $this->launchPatch(true);
        if (Shop::isFeatureActive()) {
            Shop::setContext($originalContext);
        }
        $configController = $this->context->link->getAdminLink('BconnectConfigController');
        Tools::redirectAdmin($configController);
        exit;
    }
    public function displayHookSystem(string $template, array $variables = []): string
    {
        static $modulePath = null;
        if ($modulePath === null) {
            $reflectionClass = new ReflectionClass(
                Bconnect::class
            );
            $modulePath = $reflectionClass->getFileName();
        }
        $this->context->smarty->assign($variables);
        return $this->display($modulePath, $template);
    }
    public function launchPatch(bool $install): bool
    {
        $container = new ContainerBuilder();
        $modulePath = $this->getLocalPath();
        $loader = new YamlFileLoader(
            $container,
            new FileLocator($modulePath)
        );
        $loader->load('config/patch.yml');
        $container->compile();
        $patchSystem = $container->get('nukium.bconnect.patch_system');
        $logger = $container->get('nukium.bconnect.helper.logger');
        try {
            if ($install) {
                $patchSystem->install();
            } else {
                $patchSystem->uninstall();
            }
        } catch (Exception $e) {
            $errorMessage = $e->getMessage();
            $this->_errors[] = $errorMessage;
            $logger->error("[PATCH] {$errorMessage}", [
                'exception' => $e,
            ]);
            return false;
        }
        return true;
    }
    public function getContextCacheKey(): string
    {
        return $this->getCacheId($this->name);
    }
    public function __call($method, $args)
    {
        $loggerHelper = null;
        $catch = true;
        try {
            $hookSystem = $this->get('nukium.bconnect.hook_system');
            $loggerHelper = $this->get('nukium.bconnect.helper.logger');
            if (
                !($hookSystem instanceof HookSystem) ||
                !($loggerHelper instanceof LoggerHelper)
            ) {
                throw new ModuleException('Services are not available.');
            }
            $hookName = $hookSystem->transformMethodToHookName($method);
            if ($hookName === null) {
                if (method_exists(parent::class, '__call')) {
                    return parent::__call($method, $args);
                }
                throw new ModuleException("Method \"{$method}\" not found.");
            }
            $catch = false;
            $result = $hookSystem->handle(
                $hookName,
                $args[0] ?? []
            );
            if ($result === null) {
                return;
            }
            return $result;
        } catch (Throwable $e) {
            if (!$catch) {
                throw $e;
            }
            if ($loggerHelper instanceof LoggerHelper) {
                $loggerHelper->error('Error occured in __call', [
                    'method' => $method,
                    'args' => $args,
                    'exception' => $e,
                ]);
            }
            if (
                defined('_PS_MODE_DEV_') &&
                _PS_MODE_DEV_
            ) {
                throw $e;
            }
        }
    }
}
