<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use ModuleFrontController;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use PrestaShop\PrestaShop\Adapter\ContainerFinder;
use Throwable;
use Tools;
abstract class FrontAjaxController extends ModuleFrontController
{
    const DEFAULT_ERROR_STATUS = 500;
    const HTTP_STATUS = [
        200,
        400,
        403,
        404,
        422,
        500,
    ];
    public function run()
    {
        $this->content_only = true;
        try {
            parent::run();
        } catch (Throwable $e) {
            $this->moduleLogException($e);
            $statusCode = self::DEFAULT_ERROR_STATUS;
            if (
                $e instanceof ModuleException &&
                in_array($e->getCode(), self::HTTP_STATUS)
            ) {
                $statusCode = $e->getCode();
            }
            $error = [
                'error' => $this->trans(
                    'An error has occurred.',
                    [],
                    'Modules.Bconnect.Front'
                ),
            ];
            http_response_code($statusCode);
            $this->renderJson($error, [
                'raw_rendering' => true,
            ]);
            exit;
        }
    }
    public function postProcess()
    {
        if ((int) Tools::getValue('ajax', 0) !== 1) {
            throw new ModuleException($this->trans(
                'Cron must be executed in ajax mode.',
                [],
                'Modules.Bconnect.Front'
            ), 403);
        }
    }
    public function initContent()
    {
        $this->assignGeneralPurposeVariables();
    }
    public function displayAjax()
    {
        $data = $this->callback();
        if ($data === null) {
            return;
        }
        $this->renderJson($data);
    }
    protected function renderJson(?array $data, array $options = []): void
    {
        if (!isset($options['raw_rendering'])) {
            $options['raw_rendering'] = false;
        }
        if ($data === null) {
            return;
        }
        $json = json_encode($data);
        if ($json === false) {
            if ($options['raw_rendering']) {
                exit;
            }
            throw new ModuleException($this->trans(
                'An error occurred while encoding data to JSON.',
                [],
                'Modules.Bconnect.Front'
            ), 422);
        }
        if ($options['raw_rendering']) {
            echo $json;
            exit;
        }
        if (version_compare(_PS_VERSION_, '1.7.5', '>=')) {
            $this->ajaxRender($json);
        } else {
            $this->ajaxDie($json);
        }
    }
    protected function moduleLogException(Throwable $e): void
    {
        try {
            $containerFinder = new ContainerFinder($this->context);
            $container = $containerFinder->getContainer();
            if ($container === null) {
                return;
            }
            $loggerHelper = $container->get('nukium.bconnect.helper.logger');
            if (!($loggerHelper instanceof LoggerHelper)) {
                throw new ModuleException();
            }
            $class = get_class($e);
            $message = "{$class} : An error occured";
            $loggerHelper->error($message, [
                'controller' => get_class($this),
                'exception' => $e,
            ]);
        } catch (Throwable $e) {
            return;
        }
    }
    abstract protected function callback(): ?array;
}
