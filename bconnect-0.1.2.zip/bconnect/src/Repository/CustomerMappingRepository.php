<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Db;
use DbQuery;
class CustomerMappingRepository
{
    public function findBySub(string $sub): ?int
    {
        $query = (new DbQuery())
            ->select('id_customer')
            ->from('bconnect_customer')
            ->where('sub = \'' . pSQL($sub) . '\'')
        ;
        $result = Db::getInstance()->getValue($query);
        return $result !== false ? (int) $result : null;
    }
    public function findByCustomerId(int $idCustomer): ?string
    {
        $query = (new DbQuery())
            ->select('sub')
            ->from('bconnect_customer')
            ->where('id_customer = ' . (int) $idCustomer)
        ;
        $result = Db::getInstance()->getValue($query);
        return $result !== false ? (string) $result : null;
    }
    public function save(int $idCustomer, string $sub): void
    {
        Db::getInstance()->execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'bconnect_customer`
                (`id_customer`, `sub`, `date_add`)
             VALUES
                (' . (int) $idCustomer . ', \'' . pSQL($sub) . '\', NOW())
             ON DUPLICATE KEY UPDATE
                `sub` = \'' . pSQL($sub) . '\',
                `date_add` = NOW()'
        );
    }
    public function delete(int $idCustomer): void
    {
        Db::getInstance()->execute(
            'DELETE FROM `' . _DB_PREFIX_ . 'bconnect_customer`
             WHERE `id_customer` = ' . (int) $idCustomer
        );
    }
}
