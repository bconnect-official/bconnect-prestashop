<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Oidc;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Address;
use Context;
use Country;
use Customer;
use Db;
use DbQuery;
use Exception;
use Gender;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use PrestaShop\PrestaShop\Adapter\ServiceLocator;
use Tools;
class CustomerReconciliationService
{
    private const MALE_NAMES = ['Mr', 'M.', 'Monsieur', 'Mister', 'Mr.'];
    private const FEMALE_NAMES = ['Mme', 'Mlle', 'Madame', 'Mademoiselle', 'Mrs', 'Miss', 'Ms'];
    protected $customerMappingRepository;
    protected $loggerHelper;
    public function __construct(
        CustomerMappingRepository $customerMappingRepository,
        LoggerHelper $loggerHelper
    ) {
        $this->customerMappingRepository = $customerMappingRepository;
        $this->loggerHelper = $loggerHelper;
    }
    public function reconcile(array $claims): Customer
    {
        $sub = $claims['sub'];
        $email = isset($claims['email']) ? $claims['email'] : null;
        $idCustomer = $this->customerMappingRepository->findBySub($sub);
        if ($idCustomer !== null) {
            $customer = new Customer($idCustomer);
            if (!$customer->id) {
                $this->customerMappingRepository->delete($idCustomer);
            } else {
                return $customer;
            }
        }
        if ($email !== null) {
            $customer = new Customer();
            $customer->getByEmail($email);
            if ($customer->id) {
                $this->completeCustomer($customer, $claims);
                $this->customerMappingRepository->save((int) $customer->id, $sub);
                return $customer;
            }
        }
        $customer = $this->createCustomer($claims);
        $this->customerMappingRepository->save((int) $customer->id, $sub);
        return $customer;
    }
    public function loginCustomer(Customer $customer, Context $context): void
    {
        $context->updateCustomer($customer);
    }
    public function completeCustomer(Customer $customer, array $claims): void
    {
        $this->completeProfile($customer, $claims);
        if ((int) Customer::getAddressesTotalById((int) $customer->id) === 0) {
            $this->createAddressFromClaims($customer, $claims);
        } else {
            $this->completeFirstAddressPhone($customer, $claims);
        }
    }
    protected function createCustomer(array $claims): Customer
    {
        $customer = new Customer();
        $customer->firstname = isset($claims['given_name']) ? $claims['given_name'] : 'Prénom';
        $customer->lastname = isset($claims['family_name']) ? $claims['family_name'] : 'Nom';
        $customer->email = isset($claims['email']) ? $claims['email'] : '';
        $customer->is_guest = 0;
        $customer->active = 1;
        if (isset($claims['birthdate'])) {
            $customer->birthday = $claims['birthdate'];
        }
        if (!empty($claims['civility'])) {
            $idGender = $this->findIdGenderByCivility($claims['civility']);
            if ($idGender !== null) {
                $customer->id_gender = $idGender;
            }
        }
        $crypto = ServiceLocator::get('\\PrestaShop\\PrestaShop\\Core\\Crypto\\Hashing');
        $customer->passwd = $crypto->hash(Tools::passwdGen(50));
        if (empty($customer->email)) {
            throw new ModuleException('[bconnect] Impossible de créer le compte : email manquant dans les claims');
        }
        $customer->add();
        if (!$customer->id) {
            throw new ModuleException('[bconnect] Échec de la création du compte client');
        }
        $this->createAddressFromClaims($customer, $claims);
        return $customer;
    }
    protected function completeProfile(Customer $customer, array $claims): void
    {
        $updated = false;
        if (empty($customer->firstname) && !empty($claims['given_name'])) {
            $customer->firstname = $claims['given_name'];
            $updated = true;
        }
        if (empty($customer->lastname) && !empty($claims['family_name'])) {
            $customer->lastname = $claims['family_name'];
            $updated = true;
        }
        if (
            (empty($customer->birthday) || $customer->birthday === '0000-00-00') &&
            !empty($claims['birthdate'])
        ) {
            $customer->birthday = $claims['birthdate'];
            $updated = true;
        }
        if ((int) $customer->id_gender === 0 && !empty($claims['civility'])) {
            $idGender = $this->findIdGenderByCivility($claims['civility']);
            if ($idGender !== null) {
                $customer->id_gender = $idGender;
                $updated = true;
            }
        }
        if ($updated) {
            $customer->update();
        }
    }
    protected function findIdGenderByType(string $type): ?int
    {
        $query = (new DbQuery())
            ->select('id_gender')
            ->from('gender')
            ->where('type = ' . (int) $type)
            ->orderBy('id_gender ASC')
        ;
        $result = Db::getInstance()->getValue($query);
        if ($result === false) {
            $this->loggerHelper->error('[bconnect] Aucun genre configuré pour le type demandé', ['type' => $type]);
            return null;
        }
        return (int) $result;
    }
    protected function findIdGenderByCivility(string $civility): ?int
    {
        $legacy = version_compare(_PS_VERSION_, '8.0.0', '<');
        if ($civility === 'MR') {
            return $legacy ? $this->findIdGenderByName(self::MALE_NAMES) : $this->findIdGenderByType(Gender::TYPE_MALE);
        }
        if ($civility === 'MS') {
            return $legacy ? $this->findIdGenderByName(self::FEMALE_NAMES) : $this->findIdGenderByType(Gender::TYPE_FEMALE);
        }
        return null;
    }
    protected function findIdGenderByName(array $names): ?int
    {
        $escapedNames = array_map(function ($name) {
            return "'" . pSQL(strtolower($name)) . "'";
        }, $names);
        $query = (new DbQuery())
            ->select('gl.id_gender')
            ->from('gender_lang', 'gl')
            ->where('LOWER(gl.name) IN (' . implode(',', $escapedNames) . ')')
            ->orderBy('gl.id_gender ASC')
        ;
        $result = Db::getInstance()->getValue($query);
        if ($result === false) {
            $this->loggerHelper->error('[bconnect] Aucun genre configuré pour les libellés demandés', ['names' => $names]);
            return null;
        }
        return (int) $result;
    }
    protected function createAddressFromClaims(Customer $customer, array $claims): void
    {
        if (empty($claims['postaladdress'])) {
            return;
        }
        $parts = explode('|', $claims['postaladdress']);
        if (count($parts) !== 5) {
            $this->loggerHelper->error('[bconnect] Format postaladdress invalide', ['postaladdress' => $claims['postaladdress']]);
            return;
        }
        list($streetAddress, $complementAddress, $postalCode, $locality, $country) = $parts;
        if (empty($streetAddress) || empty($locality)) {
            $this->loggerHelper->error('[bconnect] Adresse incomplète, création annulée', ['postaladdress' => $claims['postaladdress']]);
            return;
        }
        $idCountry = Country::getIdByName(null, $country);
        if (!$idCountry) {
            $this->loggerHelper->error('[bconnect] Pays introuvable pour la création d\'adresse', ['country' => $country]);
            return;
        }
        $address = new Address();
        $address->id_customer = (int) $customer->id;
        $address->alias = 'Domicile';
        $address->firstname = $customer->firstname;
        $address->lastname = $customer->lastname;
        $address->address1 = $streetAddress;
        $address->address2 = $complementAddress;
        $address->postcode = $postalCode;
        $address->city = $locality;
        $address->id_country = $idCountry;
        if (!empty($claims['phone'])) {
            $address->phone_mobile = $claims['phone'];
        }
        try {
            $address->add();
        } catch (Exception $e) {
            $this->loggerHelper->error('[bconnect] Échec de la création de l\'adresse', [
                'exception' => $e,
            ]);
        }
    }
    protected function completeFirstAddressPhone(Customer $customer, array $claims): void
    {
        if (empty($claims['phone'])) {
            return;
        }
        $idAddress = Address::getFirstCustomerAddressId((int) $customer->id);
        if (!$idAddress) {
            return;
        }
        $address = new Address((int) $idAddress);
        if (!$address->id || !empty($address->phone_mobile)) {
            return;
        }
        $address->phone_mobile = $claims['phone'];
        try {
            $address->update();
        } catch (Exception $e) {
            $this->loggerHelper->error('[bconnect] Échec de la mise à jour du téléphone sur l\'adresse', ['exception' => $e]);
        }
    }
}
