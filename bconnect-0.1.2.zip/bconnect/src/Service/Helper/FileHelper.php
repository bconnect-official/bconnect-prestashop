<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Exception\ModuleException;
use PrestaShop\PrestaShop\Core\Foundation\Filesystem\FileSystem;
use Bconnect;
class FileHelper
{
    protected $module;
    public function __construct(
        Bconnect $module
    ) {
        $this->module = $module;
    }
    public function getStorageDir(?string $path = null): string
    {
        $rootDir = _PS_ROOT_DIR_;
        $result = "{$rootDir}/var/modules/{$this->module->name}";
        if ($path !== null) {
            $path = trim($path, '/');
            $result .= "/{$path}";
        }
        if (!is_dir($result)) {
            mkdir($result, FileSystem::DEFAULT_MODE_FOLDER, true);
        }
        return $result;
    }
    public function getStorageFile(string $filename): string
    {
        $simpleFilename = basename($filename);
        $path = dirname($filename);
        $path = $this->getStorageDir($path);
        return "{$path}/{$simpleFilename}";
    }
    public function exists(string $filename): bool
    {
        $path = $this->getStorageFile($filename);
        return file_exists($path);
    }
    public function read(string $filename): string
    {
        $path = $this->getStorageFile($filename);
        $content = @file_get_contents($path);
        if ($content === false) {
            throw new ModuleException("Could not read file {$path}");
        }
        return $content;
    }
    public function write(string $filename, string $content): void
    {
        $path = $this->getStorageFile($filename);
        $result = @file_put_contents($path, $content);
        if ($result === false) {
            throw new ModuleException("Could not write to file {$path}");
        }
    }
    public function delete(string $filename): void
    {
        $path = $this->getStorageFile($filename);
        $result = @unlink($path);
        if ($result === false) {
            throw new ModuleException("Could not delete file {$path}");
        }
    }
}
