<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Psr\Cache\CacheItemInterface;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;
use Bconnect;
use Tools;
class CacheHelper
{
    protected $module;
    protected $directory;
    protected $cacheFilesystemAdapters = [];
    protected $cacheItems = [];
    public function __construct(
        Bconnect $module,
        string $directory
    ) {
        $this->module = $module;
        $this->directory = $directory;
    }
    public function has(string $name, array $options = []): bool
    {
        $options = $this->initOptions($options);
        $data = $this->getData($name, $options);
        return ($data !== null);
    }
    public function getData(string $namespace, array $options = [])
    {
        $options = $this->initOptions($options);
        $itemName = $this->generateItemName($options);
        $item = $this->getItem($namespace, $itemName);
        $data = $item->get();
        return $data;
    }
    public function setData(
        string $namespace,
        $data,
        array $options = []
    ): void {
        $options = $this->initOptions($options);
        $itemName = $this->generateItemName($options);
        $item = $this->getItem($namespace, $itemName);
        $item
            ->set($data)
            ->expiresAfter($options['ttl'])
        ;
        $filesystemAdapter = $this->getFilesystemAdapter($namespace);
        $filesystemAdapter
            ->save($item)
        ;
    }
    public function clear(string $namespace): void
    {
        $filesystemAdapter = $this->getFilesystemAdapter($namespace);
        $filesystemAdapter->clear();
        $cacheItems = [];
        foreach ($this->cacheItems as $key => $item) {
            if (strpos($key, $namespace) !== 0) {
                continue;
            }
            $cacheItems[$key] = $item;
        }
        $this->cacheItems = $cacheItems;
    }
    public function clearAll(): void
    {
        Tools::deleteDirectory($this->directory);
        $this->cacheFilesystemAdapters = [];
        $this->cacheItems = [];
    }
    protected function getFilesystemAdapter(string $namespace): FilesystemAdapter
    {
        if (!isset($this->cacheFilesystemAdapters[$namespace])) {
            $this->cacheFilesystemAdapters[$namespace] = new FilesystemAdapter(
                $namespace,
                0,
                $this->directory
            );
        }
        return $this->cacheFilesystemAdapters[$namespace];
    }
    protected function getItem(string $namespace, string $name): CacheItemInterface
    {
        $cacheKey = "{$namespace}_{$name}";
        $filesystemAdapter = $this->getFilesystemAdapter($namespace);
        if (!isset($this->cacheItems[$cacheKey])) {
            $this->cacheItems[$cacheKey] = $filesystemAdapter->getItem($name);
        }
        return $this->cacheItems[$cacheKey];
    }
    protected function generateItemName(array $options): string
    {
        $name = $this->module->name;
        if ($options['is_contextable']) {
            $name = $this->module->getContextCacheKey();
        }
        if (!empty($options['name_keys'])) {
            $name .= json_encode($options['name_keys']);
        }
        return sha1($name);
    }
    protected function initOptions(array $options): array
    {
        if (!isset($options['is_contextable'])) {
            $options['is_contextable'] = false;
        }
        if (!isset($options['ttl'])) {
            $options['ttl'] = 86400;
        }
        if (!isset($options['name_keys'])) {
            $options['name_keys'] = [];
        }
        return $options;
    }
}
