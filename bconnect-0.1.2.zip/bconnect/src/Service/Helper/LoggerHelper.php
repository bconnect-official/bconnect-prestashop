<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use DateTime;
use Nukium\Bconnect\Value\ConfigValue;
use SplFileInfo;
use Symfony\Component\Finder\Finder;
use Throwable;
class LoggerHelper
{
    const PATH = '/logs';
    protected $fileHelper;
    protected $configModuleHelper;
    protected $isCleaned = false;
    public function __construct(
        FileHelper $fileHelper,
        ConfigModuleHelper $configModuleHelper
    ) {
        $this->fileHelper = $fileHelper;
        $this->configModuleHelper = $configModuleHelper;
    }
    public function error(string $message, array $context = []): void
    {
        $this->log(
            $message,
            'error',
            $context
        );
    }
    public function debug(string $message, array $context = []): void
    {
        if (!$this->configModuleHelper->get(ConfigValue::DEBUG_MODE)) {
            return;
        }
        $this->log(
            $message,
            'debug',
            $context
        );
    }
    public function info(string $message, array $context = []): void
    {
        $this->log(
            $message,
            'info',
            $context
        );
    }
    public function getTodayLogFile(string $type): ?string
    {
        $date = date('Ymd');
        $logPath = $this->fileHelper->getStorageDir(self::PATH);
        $logPath .= "/{$type}-{$date}.log";
        if (!is_file($logPath)) {
            return null;
        }
        return $logPath;
    }
    public function log(
        string $message,
        string $type,
        array $context = []
    ): void {
        if (!isset($context['keep_logs'])) {
            $context['keep_logs'] = false;
        }
        $date = date('Ymd');
        $hour = date('H:i:s');
        $logPath = $this->fileHelper->getStorageDir(self::PATH);
        $logPath .= "/{$type}-{$date}.log";
        if (!$context['keep_logs']) {
            $this->clean($type);
        }
        unset($context['keep_logs']);
        $context = $this->handleContext($context);
        $loggedMessage = "[{$hour}] {$message}";
        if (!empty($context)) {
            $loggedMessage .= ' | ' . json_encode($context);
        }
        $loggedMessage .= "\n";
        @file_put_contents(
            $logPath,
            $loggedMessage,
            FILE_APPEND
        );
    }
    protected function clean(string $type): void
    {
        if ($this->isCleaned) {
            return;
        }
        $this->isCleaned = true;
        $rand = mt_rand(0, 4);
        if ($rand !== 4) {
            return;
        }
        $logPath = $this->fileHelper->getStorageDir(self::PATH);
        $logFiles = (new Finder())
            ->in($logPath)
            ->name("{$type}-*.log")
        ;
        foreach ($logFiles as $f) {
            $basename = $f->getBasename();
            $path = $f->getRealPath();
            $tmp = explode('-', $basename, 2);
            if (count($tmp) !== 2) {
                continue;
            }
            $horodatage = $tmp[1];
            $year = substr($horodatage, 0, 4);
            $month = substr($horodatage, 4, 2);
            $day = substr($horodatage, 6, 2);
            $logDate = DateTime::createFromFormat(
                'Y-m-d',
                "{$year}-{$month}-{$day}"
            );
            $nextMonth = new DateTime('-31 days');
            if ($nextMonth < $logDate) {
                continue;
            }
            unlink($path);
        }
    }
    protected function handleContext(array $context): array
    {
        if (
            isset($context['exception']) &&
            $context['exception'] instanceof Throwable
        ) {
            $exception = $context['exception'];
            $context['exception'] = [
                'class' => get_class($exception),
                'message' => $exception->getMessage(),
                'code' => $exception->getCode(),
                'trace' => $exception->getTraceAsString(),
            ];
        }
        return $context;
    }
}
