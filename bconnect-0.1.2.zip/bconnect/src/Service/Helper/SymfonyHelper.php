<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use AdminController;
use Context;
use Nukium\Bconnect\DTO\Util\ProxyEvent;
use PrestaShop\PrestaShop\Adapter\SymfonyContainer;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\EventDispatcher\EventDispatcherInterface as LegacyEventDispatcherInterface;
use Symfony\Component\Finder\Finder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface;
use Throwable;
class SymfonyHelper
{
    protected $context;
    public function __construct(
        Context $context
    ) {
        $this->context = $context;
    }
    public function getCurrentRequest(): ?Request
    {
        try {
            $container = $this->getContainer();
            if ($container === null) {
                return null;
            }
            $requestStack = $container->get('request_stack');
            if (!($requestStack instanceof RequestStack)) {
                return null;
            }
            return $requestStack->getCurrentRequest();
        } catch (Throwable $e) {
            return null;
        }
    }
    public function getAllEnv(): array
    {
        $result = [];
        $rootPath = _PS_ROOT_DIR_;
        $configPath = "{$rootPath}/app/config";
        $finder = (new Finder())
            ->in($configPath)
            ->depth('== 0')
            ->name('config_*.yml')
            ->files()
        ;
        foreach ($finder as $file) {
            $filename = $file->getFilename();
            $env = str_replace('config_', '', $filename);
            $env = str_replace('.yml', '', $env);
            $result[] = $env;
        }
        return $result;
    }
    public function dispatchEvent(ProxyEvent $event): void
    {
        $container = $this->getContainer();
        if ($container === null) {
            return;
        }
        try {
            $eventDispatcher = $container->get('event_dispatcher');
        } catch (Throwable $e) {
            return;
        }
        if ($eventDispatcher instanceof EventDispatcherInterface) {
            $eventDispatcher->dispatch($event);
        } elseif ($eventDispatcher instanceof LegacyEventDispatcherInterface) {
            $eventDispatcher->dispatch(
                get_class($event),
                $event
            );
        }
    }
    public function getContainer(): ?ContainerInterface
    {
        return SymfonyContainer::getInstance();
    }
}
