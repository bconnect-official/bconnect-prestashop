<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Language;
use Tab;
use Bconnect;
class AdminTabHelper
{
    const MODULE = 'module';
    const HIDE = 'hide';
    const PARENT_TAB = 'parent';
    const AFTER_TAB = 'after_tab';
    const DEFAULT_NAME = 'default_name';
    const SPECIFIC_NAME = 'specific_name';
    protected $module;
    public function __construct(
        Bconnect $module
    ) {
        $this->module = $module;
    }
    public function createTab(
        string $className,
        array $options
    ): bool {
        $module = $this->getModule($options);
        $parentTab = $this->getParentTab($options);
        $afterTab = $this->getAfterTab($options);
        $defaultName = $this->getDefaultName($options);
        $specificName = $this->getSpecificName($options);
        $tabId = (int) Tab::getIdFromClassName($className);
        if (!$tabId) {
            $tabId = null;
        }
        $tab = new Tab($tabId);
        $tab->active = 1;
        $tab->class_name = $className;
        $tab->module = $module;
        $tab->id_parent = $parentTab;
        $tab->name = [];
        foreach (Language::getLanguages() as $lang) {
            $idLang = $lang['id_lang'];
            $isoLang = $lang['iso_code'];
            $tab->name[$idLang] = (isset($specificName[$isoLang]))
                ? $specificName[$isoLang]
                : $defaultName
            ;
        }
        if (!$tab->save()) {
            return false;
        }
        if ($afterTab !== null) {
            $idTabBefore = $afterTab;
            $tabBefore = new Tab($idTabBefore);
            $newPosition = $tabBefore->position + 1;
            if ($newPosition < $tab->position) {
                $tab->updatePosition(0, $newPosition);
            } elseif ($newPosition > $tab->position) {
                $tab->updatePosition(1, $newPosition);
            }
        }
        return true;
    }
    public function removeTab(string $className): bool
    {
        $tabId = (int) Tab::getIdFromClassName($className);
        if (!$tabId) {
            return true;
        }
        return (new Tab($tabId))
            ->delete()
        ;
    }
    protected function getModule(array $options): string
    {
        return (isset($options[self::MODULE]))
            ? $options[self::MODULE]
            : $this->module->name
        ;
    }
    protected function getHide(array $options): bool
    {
        return
            isset($options[self::HIDE]) &&
            $options[self::HIDE]
        ;
    }
    protected function getParentTab(array $options): int
    {
        $hide = $this->getHide($options);
        if ($hide) {
            return -1;
        }
        return (isset($options[self::PARENT_TAB]))
            ? (int)Tab::getIdFromClassName($options[self::PARENT_TAB])
            : 0
        ;
    }
    protected function getAfterTab(array $options): ?int
    {
        return (isset($options[self::AFTER_TAB]))
            ? (int)Tab::getIdFromClassName($options[self::AFTER_TAB])
            : null
        ;
    }
    protected function getDefaultName(array $options): string
    {
        return (isset($options[self::DEFAULT_NAME]))
            ? $options[self::DEFAULT_NAME]
            : ''
        ;
    }
    protected function getSpecificName(array $options): array
    {
        return (isset($options[self::SPECIFIC_NAME]))
            ? $options[self::SPECIFIC_NAME]
            : []
        ;
    }
}
