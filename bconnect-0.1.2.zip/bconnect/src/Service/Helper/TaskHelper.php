<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Task\TaskAdapterInterface;
use Bconnect;
class TaskHelper
{
    protected $module;
    protected $symfonyHelper;
    public function __construct(
        Bconnect $module,
        SymfonyHelper $symfonyHelper
    ) {
        $this->module = $module;
        $this->symfonyHelper = $symfonyHelper;
    }
    public function getIdentifier(TaskAdapterInterface $taskAdapter): string
    {
        $taskName = $taskAdapter->getTaskName();
        return "{$this->module->name}_{$taskName}";
    }
    public function getCommandName(TaskAdapterInterface $taskAdapter): string
    {
        $taskName = $taskAdapter->getTaskName();
        return "{$this->module->name}:{$taskName}";
    }
    public function getCommandEnv(): string
    {
        $allEnv = $this->symfonyHelper->getAllEnv();
        $env = _PS_MODE_DEV_ ? 'dev' : 'prod';
        if (in_array('cli', $allEnv, true)) {
            $env = 'cli';
        }
        return $env;
    }
}
