<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Configuration;
use Context;
use Language;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Value\ConfigValue;
class ConfigModuleHelper
{
    protected $context;
    public function __construct(
        Context $context
    ) {
        $this->context = $context;
    }
    public function has(string $configName): bool
    {
        $configs = ConfigValue::ALL;
        return array_key_exists($configName, $configs);
    }
    public function get(string $configName, array $options = [])
    {
        $options = $this->initOptions($configName, $options);
        $fullConfigName = $this->getConfigName($configName);
        $this->check($configName);
        if ($options['all_lang']) {
            return $this->getAllLang($configName, $options);
        }
        if ($options['is_all_shop']) {
            $strValue = Configuration::getGlobalValue(
                $fullConfigName,
                $options['id_lang']
            );
        } else {
            $strValue = Configuration::get(
                $fullConfigName,
                $options['id_lang'],
                $options['id_shop_group'],
                $options['id_shop']
            );
        }
        return $this->extractValue($strValue, $options);
    }
    public function update(string $configName, $value, array $options = []): void
    {
        $options = $this->initOptions($configName, $options);
        $fullConfigName = $this->getConfigName($configName);
        $this->check($configName);
        if (
            $options['is_lang'] &&
            !$options['all_lang']
        ) {
            $options['all_lang'] = true;
            $idLang = (int) ($options['id_lang'] ?? $this->context->language->id);
            $tmp = $this->get($configName, $options);
            $tmp[$idLang] = $value;
            $value = $tmp;
        }
        if ($options['all_lang']) {
            if (!is_array($value)) {
                throw new ModuleException(
                    '[ConfigModuleHelper] The value must be an array when all_lang is true'
                );
            }
            foreach ($value as &$e) {
                $e = $this->encodeValue($e);
            }
            unset($e);
        } else {
            $value = $this->encodeValue($value);
        }
        if ($options['is_all_shop']) {
            Configuration::updateGlobalValue(
                $fullConfigName,
                $value,
                true
            );
        } else {
            Configuration::updateValue(
                $fullConfigName,
                $value,
                true,
                $options['id_shop_group'],
                $options['id_shop']
            );
        }
    }
    public function delete(string $configName): void
    {
        $fullConfigName = $this->getConfigName($configName);
        $this->check($configName);
        Configuration::deleteByName($fullConfigName);
    }
    public function deleteAll(array $configs): void
    {
        foreach ($configs as $configName) {
            $this->delete($configName);
        }
    }
    protected function extractValue(
        $strValue,
        array $options
    ) {
        if ($strValue === false) {
            return $options['init'];
        }
        return json_decode($strValue, true);
    }
    protected function getConfigName(string $configName): string
    {
        return ConfigValue::CONFIG_PREFIX . $configName;
    }
    protected function initOptions(string $configName, array $options): array
    {
        $configOptions = ConfigValue::ALL[$configName] ?? [];
        $options['is_lang'] = $configOptions['is_lang'] ?? false;
        if (!isset($options['is_all_shop'])) {
            $options['is_all_shop'] = $configOptions['is_all_shop'] ?? false;
        }
        if (!isset($options['init'])) {
            $options['init'] = $configOptions['init'] ?? null;
        }
        if (
            !isset($options['all_lang']) ||
            !$options['is_lang'] 
        ) {
            $options['all_lang'] = false;
        }
        if (
            !isset($options['id_lang']) ||
            !$options['is_lang'] 
        ) {
            $options['id_lang'] = (int) $this->context->language->id;
        }
        if (
            !isset($options['id_shop_group']) ||
            $options['is_all_shop'] 
        ) {
            $options['id_shop_group'] = null;
        }
        if (
            !isset($options['id_shop']) ||
            $options['is_all_shop'] 
        ) {
            $options['id_shop'] = null;
        }
        return $options;
    }
    protected function encodeValue($value): string
    {
        $strValue = json_encode($value);
        return $strValue;
    }
    protected function check(string $fullConfigName): void
    {
        if ($this->has($fullConfigName)) {
            return;
        }
        throw new ModuleException(
            '[ConfigModuleHelper] You can use only config related to module. See ConfigValue::ALL'
        );
    }
    protected function getAllLang(string $configName, array $options): array
    {
        $result = [];
        $options['all_lang'] = false;
        $allLangs = Language::getLanguages(false);
        foreach ($allLangs as $lang) {
            $idLang = (int) $lang['id_lang'];
            $options['id_lang'] = $idLang;
            $result[$idLang] = $this->get($configName, $options);
        }
        return $result;
    }
}
