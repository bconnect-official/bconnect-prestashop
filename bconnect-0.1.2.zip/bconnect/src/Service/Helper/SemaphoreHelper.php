<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Exception\ModuleException;
use Symfony\Component\Lock\Factory;
use Symfony\Component\Lock\LockFactory;
use Symfony\Component\Lock\LockInterface;
use Symfony\Component\Lock\Store\FlockStore;
class SemaphoreHelper
{
    protected $fileHelper;
    protected $factory = null;
    public function __construct(
        FileHelper $fileHelper
    ) {
        $this->fileHelper = $fileHelper;
    }
    public function createLock(
        string $name,
        array $options = []
    ): LockInterface {
        if (!isset($options['ttl'])) {
            $options['ttl'] = 1800; 
        }
        $factory = $this->getFactory();
        return $factory->createLock(
            $name,
            $options['ttl'],
            true
        );
    }
    protected function getFactory()
    {
        if ($this->factory === null) {
            $path = $this->fileHelper->getStorageDir('/semaphores');
            $store = new FlockStore($path);
            if (class_exists(LockFactory::class)) {
                $this->factory = new LockFactory($store);
            } elseif (class_exists(Factory::class)) {
                $this->factory = new Factory($store);
            }
        }
        if ($this->factory === null) {
            throw new ModuleException('[SemaphoreHelper] No suitable Lock Factory class found.');
        }
        return $this->factory;
    }
}
