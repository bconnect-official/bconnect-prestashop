<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\DataTransformer;

if (!defined('_PS_VERSION_')) {
    exit;
}

use ObjectModel;
use Symfony\Component\Form\DataTransformerInterface;
use Validate;
class ArrayToStringTransformer implements DataTransformerInterface
{
    protected $options = [
        'int' => false,
        'trim' => true,
        'allow_empty' => false,
        'object_model' => null,
    ];
    public function transform($value)
    {
        if (!is_array($value)) {
            return '';
        }
        return implode("\n", $value);
    }
    public function reverseTransform($value)
    {
        $value = str_replace("\r", '', $value);
        $result = explode("\n", $value);
        if ($this->options['int']) {
            $result = array_map('intval', $result);
        }
        if ($this->options['trim']) {
            $result = array_map('trim', $result);
        }
        if (!$this->options['allow_empty']) {
            $result = array_filter($result);
            $result = array_values($result);
        }
        if ($this->options['object_model'] !== null) {
            $temp = $result;
            $result = [];
            foreach ($temp as $item) {
                $class = $this->options['object_model'];
                if (!class_exists($class)) {
                    throw new \InvalidArgumentException(
                        "The class {$class} does not exist."
                    );
                }
                if (!is_subclass_of($class, ObjectModel::class)) {
                    throw new \InvalidArgumentException(
                        "The class {$class} is not a subclass of ObjectModel."
                    );
                }
                $o = new $class((int) $item);
                if (!Validate::isLoadedObject($o)) {
                    continue;
                }
                $result[] = (int) $o->id;
            }
        }
        return $result;
    }
    public function use(array $options): self
    {
        $cloned = clone $this;
        $cloned->options = array_merge($cloned->options, $options);
        return $cloned;
    }
}
