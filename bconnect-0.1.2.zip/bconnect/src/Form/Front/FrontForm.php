<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Front;

if (!defined('_PS_VERSION_')) {
    exit;
}

use AbstractForm;
use FormField;
use Hook;
class FrontForm extends AbstractForm
{
    public function init()
    {
        $this->formFields = $this->formatter->getFormat();
        return $this;
    }
    public function getTemplateVariables()
    {
        return [
            'action' => $this->action,
            'errors' => $this->getErrors(),
            'formFields' => array_map(
                function (FormField $field) {
                    return $field->toArray();
                },
                $this->formFields
            ),
        ];
    }
    public function validate()
    {
        if ($this->formatter instanceof AbstractFormatter) {
            $formName = $this->formatter->getFormName();
            $hookName = "validate{$formName}FrontFormFields";
            Hook::exec($hookName, [
                'fields' => $this->formFields,
            ]);
        }
        return parent::validate();
    }
    public function submit()
    {
        if (!$this->validate()) {
            return false;
        }
        if ($this->formatter instanceof AbstractFormatter) {
            $formName = $this->formatter->getFormName();
            $hookName = "submit{$formName}FrontFormFields";
            Hook::exec($hookName, [
                'fields' => $this->formFields,
            ]);
        }
        return true;
    }
}
