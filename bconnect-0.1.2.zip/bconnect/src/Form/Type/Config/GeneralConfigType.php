<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Type\Config;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use Nukium\Bconnect\Form\EventListener\ConfigurationDataListener;
use Nukium\Bconnect\Form\Type\Util\ChoiceWithPictoType;
use Nukium\Bconnect\Form\Type\Util\CopyableLinkType;
use Nukium\Bconnect\Value\ButtonValue;
use Nukium\Bconnect\Value\ConfigValue;
use Nukium\Bconnect\Value\EnvironmentValue;
use Nukium\Bconnect\Value\ScopeValue;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
class GeneralConfigType extends TranslatorAwareType
{
    protected $configurationDataListener;
    protected $context;
    public function __construct(
        $translator,
        array $locales,
        ConfigurationDataListener $configurationDataListener,
        Context $context
    ) {
        parent::__construct(
            $translator,
            $locales
        );
        $this->configurationDataListener = $configurationDataListener;
        $this->context = $context;
    }
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        parent::buildForm($builder, $options);
        $builder
            ->add(ConfigValue::CLIENT_ID, TextType::class, [
                'label' => $this->trans('Client ID', 'Modules.Bconnect.Admin'),
                'required' => true,
            ])
            ->add(ConfigValue::CLIENT_SECRET, TextType::class, [
                'label' => $this->trans('Client secret', 'Modules.Bconnect.Admin'),
                'required' => true,
            ])
            ->add('REDIRECT_URI', CopyableLinkType::class, [
                'label' => $this->trans('Redirect URI', 'Modules.Bconnect.Admin'),
                'data' => $this->context->link->getModuleLink('bconnect', 'callback'),
                'help' => $this->trans(
                    'Provide this URL to b.connect to finalize the integration.',
                    'Modules.Bconnect.Admin'
                ),
            ])
            ->add(ConfigValue::SCOPES, ChoiceType::class, [
                'label' => $this->trans('Requested scopes', 'Modules.Bconnect.Admin'),
                'choices' => [
                    $this->trans('OpenID (required)', 'Modules.Bconnect.Admin') => ScopeValue::OPENID,
                    $this->trans('Email (required)', 'Modules.Bconnect.Admin') => ScopeValue::EMAIL,
                    $this->trans('First name (given_name)', 'Modules.Bconnect.Admin') => ScopeValue::GIVEN_NAME,
                    $this->trans('Last name (family_name)', 'Modules.Bconnect.Admin') => ScopeValue::FAMILY_NAME,
                    $this->trans('Postal address (postaladdress)', 'Modules.Bconnect.Admin') => ScopeValue::POSTALADDRESS,
                    $this->trans('Mobile phone (phone)', 'Modules.Bconnect.Admin') => ScopeValue::PHONE,
                ],
                'choice_attr' => function ($choice) {
                    return in_array($choice, ScopeValue::MANDATORY, true)
                        ? ['disabled' => 'disabled']
                        : []
                    ;
                },
                'choice_translation_domain' => false,
                'expanded' => true,
                'multiple' => true,
                'required' => false,
            ])
            ->add(ConfigValue::ENVIRONMENT, ChoiceType::class, [
                'label' => $this->trans('Environment', 'Modules.Bconnect.Admin'),
                'choices' => [
                    $this->trans('Qualification', 'Modules.Bconnect.Admin') => EnvironmentValue::QUALIFICATION,
                    $this->trans('Production', 'Modules.Bconnect.Admin') => EnvironmentValue::PRODUCTION,
                ],
                'choice_translation_domain' => false,
                'expanded' => true,
                'multiple' => false,
                'required' => true,
            ])
            ->add(ConfigValue::BUTTON_STYLE, ChoiceWithPictoType::class, [
                'label' => $this->trans('Button style', 'Modules.Bconnect.Admin'),
                'choices' => [
                    $this->trans('Icon only', 'Modules.Bconnect.Admin') => ButtonValue::STYLE_ICON,
                    $this->trans('Button - blue', 'Modules.Bconnect.Admin') => ButtonValue::STYLE_STANDARD_BLUE,
                    $this->trans('Button - white', 'Modules.Bconnect.Admin') => ButtonValue::STYLE_STANDARD_WHITE,
                    $this->trans('Contextual button - blue', 'Modules.Bconnect.Admin') => ButtonValue::STYLE_CONTEXTUAL_BLUE,
                    $this->trans('Contextual button - white', 'Modules.Bconnect.Admin') => ButtonValue::STYLE_CONTEXTUAL_WHITE,
                ],
                'images' => ButtonValue::STYLE_PREVIEW_IMAGES,
                'choice_translation_domain' => false,
                'expanded' => true,
                'multiple' => false,
                'required' => true,
            ])
            ->add(ConfigValue::DISPLAY_SLOGAN, SwitchType::class, [
                'label' => $this->trans('Display an information text before the button', 'Modules.Bconnect.Admin'),
                'required' => false,
            ])
            ->addEventSubscriber($this->configurationDataListener)
        ;
        $builder->get(ConfigValue::SCOPES)->addEventListener(
            FormEvents::PRE_SUBMIT,
            function (FormEvent $event) {
                $data = $event->getData();
                if (!is_array($data)) {
                    $data = [];
                }
                $data = array_merge(
                    ScopeValue::MANDATORY,
                    $data
                );
                $data = array_unique($data);
                $data = array_values($data);
                $event->setData($data);
            },
            10
        );
    }
}
