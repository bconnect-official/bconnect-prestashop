<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Type\Config;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Form\EventListener\ConfigurationDataListener;
use Nukium\Bconnect\Form\Type\Util\AdminLinkType;
use Nukium\Bconnect\Value\ConfigValue;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\FormBuilderInterface;
class AdvancedConfigType extends TranslatorAwareType
{
    protected $configurationDataListener;
    public function __construct(
        $translator,
        array $locales,
        ConfigurationDataListener $configurationDataListener
    ) {
        parent::__construct(
            $translator,
            $locales
        );
        $this->configurationDataListener = $configurationDataListener;
    }
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        parent::buildForm($builder, $options);
        $builder
            ->add(ConfigValue::DEBUG_MODE, SwitchType::class, [
                'label' => $this->trans('Enable debug mode', 'Modules.Bconnect.Admin'),
                'help' => $this->trans(
                    'Silently logs more detailed information useful for debugging.',
                    'Modules.Bconnect.Admin'
                ),
                'required' => false,
            ])
            ->add('DOWNLOAD_ERROR_LOG', AdminLinkType::class, [
                'label' => $this->trans('Error log', 'Modules.Bconnect.Admin'),
                'button_label' => $this->trans("Download today's error log", 'Modules.Bconnect.Admin'),
                'route' => 'bconnect_config_download_log',
                'route_parameters' => ['type' => 'error'],
            ])
            ->add('DOWNLOAD_DEBUG_LOG', AdminLinkType::class, [
                'label' => $this->trans('Debug log', 'Modules.Bconnect.Admin'),
                'button_label' => $this->trans("Download today's debug log", 'Modules.Bconnect.Admin'),
                'route' => 'bconnect_config_download_log',
                'route_parameters' => ['type' => 'debug'],
            ])
            ->addEventSubscriber($this->configurationDataListener)
        ;
    }
}
