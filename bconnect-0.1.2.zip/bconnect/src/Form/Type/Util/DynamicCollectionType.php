<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Type\Util;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormRenderer;
use Symfony\Component\Form\FormView;
use Twig\Environment;
class DynamicCollectionType extends TranslatorAwareType
{
    protected $twig;
    public function __construct(
        $translator,
        array $locales,
        Environment $twig
    ) {
        parent::__construct(
            $translator,
            $locales
        );
        $this->twig = $twig;
    }
    public function buildView(
        FormView $view,
        FormInterface $form,
        array $options
    ): void {
        $random = bin2hex(random_bytes(8));
        $view->vars['container_id'] = "bconnect-dynamic-collection-{$random}";
        $this->twig->getRuntime(FormRenderer::class)->setTheme(
            $view,
            '@Modules/bconnect/views/templates/admin/_partials/dynamic_collection.html.twig'
        );
        parent::buildView($view, $form, $options);
    }
    public function getBlockPrefix(): string
    {
        return 'bconnect_dynamic_collection';
    }
    public function getParent(): string
    {
        return CollectionType::class;
    }
}
