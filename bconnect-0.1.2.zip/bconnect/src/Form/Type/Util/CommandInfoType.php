<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Type\Util;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Language;
use Nukium\Bconnect\Service\Helper\TaskHelper;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
class CommandInfoType extends TranslatorAwareType
{
    protected $taskHelper;
    public function __construct(
        $translator,
        array $locales,
        TaskHelper $taskHelper
    ) {
        parent::__construct(
            $translator,
            $locales
        );
        $this->taskHelper = $taskHelper;
    }
    public function configureOptions(OptionsResolver $resolver): void
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults([
            'command' => null,
            'multi_lang' => false,
        ]);
    }
    public function buildView(
        FormView $view,
        FormInterface $form,
        array $options
    ): void {
        parent::buildView($view, $form, $options);
        $command = $options['command'];
        $env = $this->taskHelper->getCommandEnv();
        $phpVersion = phpversion();
        $allLangs = Language::getLanguages(false);
        $phpVersion = explode('.', $phpVersion);
        $phpVersion = "{$phpVersion[0]}.{$phpVersion[1]}";
        if (strpos($_SERVER['SERVER_NAME'], '.local') === false) {
            $phpBin = 'php';
        } else {
            $phpBin = "php{$phpVersion}";
        }
        $message = "{$phpBin} bin/console {$command} --no-debug --env {$env}";
        if (
            $options['multi_lang'] &&
            count($allLangs) > 1
        ) {
            $tmpMessage = '';
            foreach ($allLangs as $lang) {
                $idLang = (int) $lang['id_lang'];
                $tmpMessage .= "{$message} --id_lang {$idLang}<br>\n";
            }
            $message = $tmpMessage;
        }
        $view->vars['message'] = $message;
    }
    public function getParent(): string
    {
        return MessageAlertType::class;
    }
}
