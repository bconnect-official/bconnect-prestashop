<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Form\Validator;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Serializer\Exception\NotEncodableValueException;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
class CsvCheckerValidator extends ConstraintValidator
{
    private $serializer;
    public function __construct(
        SerializerInterface $serializer
    ) {
        $this->serializer = $serializer;
    }
    public function validate($value, Constraint $constraint): void
    {
        if (!$constraint instanceof CsvChecker) {
            throw new UnexpectedTypeException($constraint, CsvChecker::class);
        }
        if ($value === null) {
            return;
        }
        if (!$value instanceof UploadedFile) {
            throw new UnexpectedTypeException($value, UploadedFile::class);
        }
        if ($value->getClientOriginalExtension() !== 'csv') {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ error }}', 'L\'extension du fichier doit être ".csv"')
                ->addViolation()
            ;
            return;
        }
        $csvContent = file_get_contents($value->getRealPath());
        if ($csvContent === false) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ error }}', 'Impossible de lire le fichier')
                ->addViolation()
            ;
            return;
        }
        try {
            $parsedData = $this->serializer->decode($csvContent, 'csv', [
                'csv_delimiter' => $constraint->separator,
            ]);
        } catch (NotEncodableValueException $e) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ error }}', "Impossible de parser le fichier avec le séparateur \"{$constraint->separator}\"")
                ->addViolation()
            ;
            return;
        }
        if (empty($parsedData)) {
            return;
        }
        if (
            isset($parsedData['id_product']) ||
            isset($parsedData['id_product_attribute'])
        ) {
            $parsedData = [$parsedData];
        }
        $parsedData = $parsedData[0];
        if (!empty($constraint->columns)) {
            $fileColumns = array_keys($parsedData);
            $missingColumns = array_diff($constraint->columns, $fileColumns);
            $extraColumns = array_diff($fileColumns, $constraint->columns);
            $missingColumnsStr = implode(', ', $missingColumns);
            $extraColumnsStr = implode(', ', $extraColumns);
            if (!empty($missingColumns)) {
                $this->context->buildViolation($constraint->message)
                    ->setParameter('{{ error }}', "Colonnes manquantes : {$missingColumnsStr}.")
                    ->addViolation()
                ;
                return;
            }
            if (!empty($extraColumns)) {
                $this->context->buildViolation($constraint->message)
                    ->setParameter('{{ error }}', "Colonnes supplémentaires détectées : {$extraColumnsStr}.")
                    ->addViolation()
                ;
                return;
            }
        }
    }
}
