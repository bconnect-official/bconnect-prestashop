<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use Bconnect;
use Nukium\Bconnect\Form\Type\ConfigType;
use Nukium\Bconnect\Service\Handler\ConfigEventHandler;
use Nukium\Bconnect\Service\Handler\ConfigSubmitEventHandler;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Nukium\Bconnect\Service\Helper\SymfonyHelper;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
class ConfigController extends FrameworkBundleAdminController
{
    protected $module;
    protected $configModuleHelper;
    protected $symfonyHelper;
    protected $configEventHandler;
    protected $configSubmitEventHandler;
    protected $loggerHelper;
    public function __construct(
        Bconnect $module,
        ConfigModuleHelper $configModuleHelper,
        SymfonyHelper $symfonyHelper,
        ConfigEventHandler $configEventHandler,
        ConfigSubmitEventHandler $configSubmitEventHandler,
        LoggerHelper $loggerHelper
    ) {
        $this->module = $module;
        $this->configModuleHelper = $configModuleHelper;
        $this->symfonyHelper = $symfonyHelper;
        $this->configEventHandler = $configEventHandler;
        $this->configSubmitEventHandler = $configSubmitEventHandler;
        $this->loggerHelper = $loggerHelper;
    }
    public function indexAction(Request $request): Response
    {
        $configEvent = $this->configEventHandler->create()
            ->setRequest($request)
        ;
        $this->symfonyHelper->dispatchEvent($configEvent);
        $form = $this->createForm(ConfigType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $data = $this->extractInputs($form);
            $data = $this->flatFormData($data);
            $configSubmitEvent = $this->configSubmitEventHandler->create()
                ->setRequest($request)
                ->setForm($form)
                ->setData($data)
            ;
            $this->symfonyHelper->dispatchEvent($configSubmitEvent);
            $data = $configSubmitEvent->getData();
            foreach ($data as $element) {
                try {
                    $configName = $element['name'];
                    $value = $element['value'];
                    if ($this->configModuleHelper->has($configName)) {
                        $this->configModuleHelper->update($configName, $value, [
                            'all_lang' => true,
                        ]);
                    }
                } catch (Exception $e) {
                    $this->loggerHelper->error('[bconnect] Erreur sauvegarde configuration', [
                        'config_name' => $configName ?? null,
                        'exception' => $e,
                    ]);
                    $this->addFlash(
                        'error',
                        $e->getMessage()
                    );
                }
            }
            $this->addFlash('success', $this->trans(
                'Settings updated',
                'Admin.Global'
            ));
        }
        return $this->render('@Modules/bconnect/views/templates/admin/config/index.html.twig', [
            'enableSidebar' => true,
            'layoutHeaderToolbarBtn' => [],
            'layoutTitle' => $this->trans(
                'Module configuration',
                'Modules.Bconnect.Admin'
            ),
            'requireAddonsSearch' => false,
            'requireBulkActions' => false,
            'requireFilterStatus' => false,
            'showContentHeader' => true,
            'can_use_legacy_form' => version_compare(_PS_VERSION_, '1.7.6', '>='),
            'use_legacy_form' => version_compare(_PS_VERSION_, '1.7.8', '<'),
            'display_global_save' => $configEvent->getDisplayGlobalSave(),
            'form' => $form->createView(),
        ]);
    }
    public function downloadLogAction(string $type): Response
    {
        $logFile = $this->loggerHelper->getTodayLogFile($type);
        if ($logFile === null) {
            throw $this->createNotFoundException(
                "No {$type} log file for today"
            );
        }
        $response = new BinaryFileResponse($logFile);
        $response->setContentDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            basename($logFile)
        );
        return $response;
    }
    protected function extractInputs(FormInterface $form): array
    {
        $finalInputs = [];
        foreach ($form as $child) {
            $finalInputs[] = $child;
            if ($child->count() > 0) {
                $finalInputs = array_merge(
                    $finalInputs,
                    $this->extractInputs($child)
                );
            }
        }
        return $finalInputs;
    }
    protected function flatFormData(array $finalInputs): array
    {
        $data = [];
        foreach ($finalInputs as $input) {
            $names = [];
            $tmp = $input;
            while ($tmp->getParent()) {
                array_unshift(
                    $names,
                    $tmp->getName()
                );
                $tmp = $tmp->getParent();
            }
            $key = implode('.', $names);
            array_pop($names);
            $data[$key] = [
                'value' => $input->getData(),
                'name' => $input->getName(),
                'parents' => $names,
            ];
        }
        return $data;
    }
}
