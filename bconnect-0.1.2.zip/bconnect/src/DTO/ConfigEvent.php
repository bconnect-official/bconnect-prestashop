<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

namespace Nukium\Bconnect\DTO;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\DTO\Util\ProxyEvent;
use Symfony\Component\HttpFoundation\Request;
class ConfigEvent extends ProxyEvent
{
    protected $request = null;
    protected $displayGlobalSave = true;
    public function getRequest(): ?Request
    {
        return $this->request;
    }
    public function setRequest(?Request $request): self
    {
        $this->request = $request;
        return $this;
    }
    public function getDisplayGlobalSave(): bool
    {
        return $this->displayGlobalSave;
    }
    public function setDisplayGlobalSave(bool $displayGlobalSave): self
    {
        $this->displayGlobalSave = $displayGlobalSave;
        return $this;
    }
}
