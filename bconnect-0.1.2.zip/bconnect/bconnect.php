<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2025 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Helper\ModuleHelper;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
require_once dirname(__FILE__) . '/vendor/autoload.php';
class Bconnect extends ModuleHelper implements WidgetInterface
{
    public function __construct()
    {
        $this->name = 'bconnect';
        $this->tab = 'front_office_features';
        $this->version = '0.1.2';
        $this->author = 'Nukium';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->trans(
            'b.connect',
            [],
            'Modules.Bconnect.Admin'
        );
        $this->description = $this->trans(
            'Authentication and account creation via b.connect',
            [],
            'Modules.Bconnect.Admin'
        );
        $this->ps_versions_compliancy = [
            'min' => '1.7.6',
            'max' => _PS_VERSION_,
        ];
    }
    public function getWidgetVariables($hookName, array $params)
    {
        $configModuleHelper = $this->get('nukium.bconnect.helper.config_module');
        if (
            !($configModuleHelper instanceof ConfigModuleHelper)
        ) {
            throw new ModuleException('Impossible to retrieve services');
        }
        $defaultVariant = 'connect';
        if ($hookName === 'displayCustomerAccountFormTop') {
            $defaultVariant = 'create';
        }
        $forceVariant = isset($params['bconnect_variant']);
        $variant = ($forceVariant)
            ? $params['bconnect_variant']
            : $defaultVariant
        ;
        $style = (isset($params['bconnect_style']))
            ? $params['bconnect_style']
            : $configModuleHelper->get(ConfigValue::BUTTON_STYLE)
        ;
        $origin = (!empty($params['bconnect_origin']))
            ? $params['bconnect_origin']
            : null
        ;
        $clientId = $configModuleHelper->get(ConfigValue::CLIENT_ID);
        $clientSecret = $configModuleHelper->get(ConfigValue::CLIENT_SECRET);
        if (
            empty($clientId) ||
            empty($clientSecret)
        ) {
            return null;
        }
        $authorizeUrlParams = [];
        if ($origin !== null) {
            $authorizeUrlParams['origin'] = $origin;
        }
        return [
            'bconnect_variant' => $variant,
            'bconnect_style' => $style,
            'bconnect_display_slogan' => (bool) $configModuleHelper->get(ConfigValue::DISPLAY_SLOGAN),
            'bconnect_force_variant' => $forceVariant,
            'bconnect_module_dir' => $this->getPathUri(),
            'bconnect_authorize_url' => $this->context->link->getModuleLink(
                $this->name,
                'authorize',
                $authorizeUrlParams
            ),
        ];
    }
    public function renderWidget($hookName, array $params)
    {
        $vars = $this->getWidgetVariables($hookName, $params);
        if ($vars === null) {
            return '';
        }
        return $this->displayHookSystem('button.tpl', $vars);
    }
}
