{*
*  Module made by Nukium
*
*  @author    Nukium
*  @copyright 2025 Nukium SAS
*  @license   All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*}
{* Variante sidebar (account-menu--sidebar) : lien simple vers le compte client *}
<a class="account-menu__link bconnect-account-block--sidebar" id="bconnect_sidebar_link" href="{$urls.pages.my_account|escape:'html':'UTF-8'}">
    <div class="bconnect-account-block__logo">
        <img
            src="{$bconnect_module_dir}views/img/bconnect_button.svg"
            alt="b.connect"
            class="bconnect-account-block__icon"
        />
        <span class="bconnect-account-block__title">{l s='b.connect' d='Modules.Bconnect.Shop'}</span>
    </div>
</a>

{* Variante grille principale (account-menu--main) : bloc complet de liaison *}
<div class="account-menu__link bconnect-account-block--main">
    <div class="bconnect-account-block">
        <div class="bconnect-account-block__logo">
            <img
                src="{$bconnect_module_dir}views/img/bconnect_button.svg"
                alt="b.connect"
                class="bconnect-account-block__icon"
            />
            <span class="bconnect-account-block__title">{l s='b.connect' d='Modules.Bconnect.Shop'}</span>
        </div>

        {if $bconnect_is_paired}
            <p class="bconnect-account-block__status bconnect-account-block__status--linked">
                {l s='Your account is linked to b.connect.' d='Modules.Bconnect.Shop'}
            </p>
            <form action="{$bconnect_unlink_url|escape:'html':'UTF-8'}" method="post" class="bconnect-account-block__form">
                <input type="hidden" name="action" value="unlink" />
                <input type="hidden" name="token" value="{$bconnect_token|escape:'html':'UTF-8'}" />
                <button type="submit" class="bconnect-account-block__btn bconnect-account-block__btn--unlink btn btn-secondary">
                    {l s='Unlink b.connect' d='Modules.Bconnect.Shop'}
                </button>
            </form>
        {else}
            <p class="bconnect-account-block__status">
                {l s='Link your account to sign in quickly with b.connect.' d='Modules.Bconnect.Shop'}
            </p>
            <form action="{$bconnect_pair_url|escape:'html':'UTF-8'}" method="post" class="bconnect-account-block__form">
                <button type="submit" class="bconnect-account-block__btn bconnect-account-block__btn--link btn btn-primary btn-sm">
                    {l s='Link my b.connect account' d='Modules.Bconnect.Shop'}
                </button>
            </form>
        {/if}
    </div>
</div>
