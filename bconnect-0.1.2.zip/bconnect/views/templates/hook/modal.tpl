{*
*  Module made by Nukium
*
*  @author    Nukium
*  @copyright 2025 Nukium SAS
*  @license   All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*}
<div
    class="modal fade bconnect-modal"
    id="bconnect-informations-modal"
    tabindex="-1"
    role="dialog"
    aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content bconnect-modal__content">
            <div class="modal-body">
                <button
                    type="button"
                    class="bconnect-modal__close btn-close"
                    data-dismiss="modal"
                    data-bs-dismiss="modal"
                    aria-label="{l s='Close' d='Modules.Bconnect.Shop'}"
                ></button>
                <iframe
                    src="https://www.bconnect.net/modale/fr/modale.htm"
                    class="bconnect-modal__iframe"
                    title="{l s='b.connect information' d='Modules.Bconnect.Shop'}"
                    loading="lazy"
                    frameborder="0"
                ></iframe>
            </div>
        </div>
    </div>
</div>
