<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Helper\ModuleHelper;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
require_once dirname(__FILE__) . '/vendor/autoload.php';
class Bconnect extends ModuleHelper implements WidgetInterface
{
    public function __construct()
    {
        $this->name = 'bconnect';
        $this->tab = 'front_office_features';
        $this->version = '1.0.1';
        $this->author = 'Nukium';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->trans(
            'b.connect',
            [],
            'Modules.Bconnect.Admin'
        );
        $this->description = $this->trans(
            'Authentication and account creation via b.connect',
            [],
            'Modules.Bconnect.Admin'
        );
        $this->ps_versions_compliancy = [
            'min' => '1.7.6',
            'max' => _PS_VERSION_,
        ];
    }
    public function getWidgetVariables($hookName, array $params)
    {
        $configModuleHelper = $this->get('nukium.bconnect.helper.config_module');
        if (
            !($configModuleHelper instanceof ConfigModuleHelper)
        ) {
            throw new ModuleException('Impossible to retrieve services');
        }
        $defaultVariant = 'connect';
        if ($hookName === 'displayCustomerAccountFormTop') {
            $defaultVariant = 'create';
        }
        $forceVariant = isset($params['bconnect_variant']);
        $variant = ($forceVariant)
            ? $params['bconnect_variant']
            : $defaultVariant
        ;
        $style = (isset($params['bconnect_style']))
            ? $params['bconnect_style']
            : $configModuleHelper->get(ConfigValue::BUTTON_STYLE)
        ;
        $origin = (!empty($params['bconnect_origin']))
            ? $params['bconnect_origin']
            : null
        ;
        $clientId = $configModuleHelper->get(ConfigValue::CLIENT_ID);
        $clientSecret = $configModuleHelper->get(ConfigValue::CLIENT_SECRET);
        if (
            empty($clientId) ||
            empty($clientSecret)
        ) {
            return null;
        }
        $authorizeUrlParams = [];
        if ($origin !== null) {
            $authorizeUrlParams['origin'] = $origin;
        }
        return [
            'bconnect_variant' => $variant,
            'bconnect_style' => $style,
            'bconnect_display_slogan' => (bool) $configModuleHelper->get(ConfigValue::DISPLAY_SLOGAN),
            'bconnect_force_variant' => $forceVariant,
            'bconnect_module_dir' => $this->getPathUri(),
            'bconnect_authorize_url' => $this->context->link->getModuleLink(
                $this->name,
                'authorize',
                $authorizeUrlParams
            ),
        ];
    }
    public function renderWidget($hookName, array $params)
    {
        $vars = $this->getWidgetVariables($hookName, $params);
        if ($vars === null) {
            return '';
        }
        return $this->displayHookSystem('button.tpl', $vars);
    }
}
