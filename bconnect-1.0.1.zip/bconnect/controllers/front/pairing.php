<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Repository\CustomerMappingRepository;
class BconnectPairingModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        try {
            if (!$this->context->customer->isLogged()) {
                Tools::redirect($this->context->link->getPageLink('authentication'));
                return;
            }
            $action = Tools::getValue('action');
            if ($action === 'unlink') {
                $this->handleUnlink();
            } else {
                $this->handleLinkRedirect();
            }
        } catch (Exception $e) {
            $this->module->get('nukium.bconnect.helper.logger')->error(
                '[bconnect] Erreur pairing',
                ['exception' => $e]
            );
            Tools::redirect($this->context->link->getPageLink('my-account'));
        }
    }
    protected function handleUnlink(): void
    {
        if (!Tools::isSubmit('token') || Tools::getValue('token') !== $this->context->customer->secure_key) {
            $this->redirectWithError();
            return;
        }
        $repository = $this->module->get('nukium.bconnect.repository.customer_mapping');
        $repository->delete((int) $this->context->customer->id);
        Tools::redirect($this->context->link->getPageLink('my-account'));
    }
    protected function handleLinkRedirect(): void
    {
        Tools::redirect(
            $this->context->link->getModuleLink('bconnect', 'authorize') . '?action=pair'
        );
    }
    protected function redirectWithError(): void
    {
        Tools::redirect($this->context->link->getPageLink('my-account'));
    }
}
