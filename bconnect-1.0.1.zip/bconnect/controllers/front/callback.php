<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use Nukium\Bconnect\Exception\LogicException;
use Nukium\Bconnect\Exception\StateMismatchException;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
use Nukium\Bconnect\Service\Oidc\CustomerReconciliationService;
use Nukium\Bconnect\Service\Oidc\OidcService;
class BconnectCallbackModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        try {
            $this->handleCallback();
        } catch (LogicException $e) {
            $this->module->get('nukium.bconnect.helper.logger')->error(
                '[bconnect] Tentative d\'appairage refusée',
                ['exception' => $e]
            );
            $this->errors[] = $this->trans(
                'This b.connect account is already linked to another customer account.',
                [],
                'Modules.Bconnect.Shop'
            );
            $this->redirectWithNotifications(
                $this->context->link->getPageLink('my-account')
            );
        } catch (StateMismatchException $e) {
            $this->module->get('nukium.bconnect.helper.logger')->error(
                '[bconnect] State absent du cookie de session',
                ['exception' => $e]
            );
            if ($this->context->customer->isLogged()) {
                Tools::redirect($this->context->link->getPageLink('my-account'));
                return;
            }
            $this->errors[] = $this->trans(
                'The b.connect sign-in could not be completed because it was not started from this browser (private browsing, or a different browser). Please start a new b.connect sign-in from this page.',
                [],
                'Modules.Bconnect.Shop'
            );
            $this->redirectWithNotifications(
                $this->context->link->getPageLink('authentication')
            );
        } catch (Exception $e) {
            $this->module->get('nukium.bconnect.helper.logger')->error(
                '[bconnect] Erreur callback OIDC',
                ['exception' => $e]
            );
            $this->errors[] = $this->trans(
                'An error occurred while connecting with b.connect. Please try again.',
                [],
                'Modules.Bconnect.Shop'
            );
            $this->redirectWithNotifications(
                $this->context->link->getPageLink('authentication')
            );
        }
    }
    protected function handleCallback(): void
    {
        $loggerHelper = $this->module->get('nukium.bconnect.helper.logger');
        $code = Tools::getValue('code');
        $state = Tools::getValue('state');
        $error = Tools::getValue('error');
        if ($error) {
            throw new Exception('[bconnect] Erreur retournée par b.connect : ' . pSQL($error));
        }
        if (empty($code) || empty($state)) {
            throw new Exception('[bconnect] Paramètres code ou state manquants');
        }
        $storedState = $this->context->cookie->bconnect_state;
        if (empty($storedState)) {
            throw new StateMismatchException('[bconnect] State absent du cookie de session');
        }
        if (!hash_equals($storedState, $state)) {
            throw new Exception('[bconnect] State invalide');
        }
        $storedNonce = $this->context->cookie->bconnect_nonce;
        $action = $this->context->cookie->bconnect_action;
        unset(
            $this->context->cookie->bconnect_state,
            $this->context->cookie->bconnect_nonce,
            $this->context->cookie->bconnect_action
        );
        $this->context->cookie->write();
        $oidcService = $this->module->get('nukium.bconnect.service.oidc');
        $redirectUri = $this->context->link->getModuleLink('bconnect', 'callback');
        $tokens = $oidcService->exchangeCode($code, $redirectUri);
        $loggerHelper->debug('[bconnect] Réponse token', ['tokens' => $tokens]);
        if (empty($tokens['access_token'])) {
            throw new Exception('[bconnect] access_token absent de la réponse token');
        }
        if (empty($tokens['token_type'])) {
            throw new Exception('[bconnect] token_type absent de la réponse token');
        }
        if (empty($tokens['id_token'])) {
            throw new Exception('[bconnect] id_token absent de la réponse token');
        }
        $claims = $oidcService->validateIdToken($tokens['id_token'], $storedNonce);
        $loggerHelper->debug('[bconnect] action', ['action' => $action]);
        $loggerHelper->debug('[bconnect] claims', ['claims' => $claims]);
        if ($action === 'pair') {
            $this->handlePairing($claims);
        } else {
            $this->handleLogin($claims, $action);
        }
    }
    protected function handleLogin(array $claims, string $action): void
    {
        $reconciliationService = $this->module->get('nukium.bconnect.service.customer_reconciliation');
        $customer = $reconciliationService->reconcile($claims);
        $reconciliationService->loginCustomer($customer, $this->context);
        $redirectPage = $action === 'checkout' ? 'order' : 'my-account';
        Tools::redirect($this->context->link->getPageLink($redirectPage));
    }
    protected function handlePairing(array $claims): void
    {
        if (!$this->context->customer->isLogged()) {
            throw new Exception('[bconnect] Tentative d\'appairage sans être connecté');
        }
        $repository = $this->module->get('nukium.bconnect.repository.customer_mapping');
        $idCustomer = (int) $this->context->customer->id;
        $existingIdCustomer = $repository->findBySub($claims['sub']);
        if ($existingIdCustomer !== null && $existingIdCustomer !== $idCustomer) {
            throw new LogicException(sprintf(
                '[bconnect] Le sub %s est déjà associé au client #%d (tentative d\'appairage par le client #%d)',
                $claims['sub'],
                $existingIdCustomer,
                $idCustomer
            ));
        }
        $repository->save($idCustomer, $claims['sub']);
        $reconciliationService = $this->module->get('nukium.bconnect.service.customer_reconciliation');
        $reconciliationService->completeCustomer($this->context->customer, $claims);
        Tools::redirect($this->context->link->getPageLink('my-account'));
    }
}
