<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Hook;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Service\Helper\LoggerHelper;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use Throwable;
use Bconnect;
class HookSystem
{
    protected $module;
    protected $loggerHelper;
    protected $components;
    public function __construct(
        Bconnect $module,
        LoggerHelper $loggerHelper,
        iterable $hooks
    ) {
        $this->module = $module;
        $this->loggerHelper = $loggerHelper;
        $this->components = iterator_to_array($hooks);
    }
    public function handle(string $hookName, array $params)
    {
        $result = null;
        $allComponents = $this->getComponents();
        $isDisplayHook = $this->isDisplayHook($hookName);
        if ($isDisplayHook) {
            $result = '';
        }
        if (!$this->hasHook($hookName)) {
            if (
                $isDisplayHook &&
                $this->module instanceof WidgetInterface
            ) {
                try {
                    $result = $this->module->renderWidget($hookName, $params);
                } catch (Throwable $e) {
                    $this->loggerHelper->error('Error occured in renderWidget', [
                        'hook_name' => $hookName,
                        'exception' => $e,
                    ]);
                    if (
                        defined('_PS_MODE_DEV_') &&
                        _PS_MODE_DEV_
                    ) {
                        throw $e;
                    }
                }
            } else {
                $this->loggerHelper->info(
                    "Hook \"{$hookName}\" not found. Check if you forgot to remove the hook."
                );
            }
            return $result;
        }
        foreach ($allComponents[$hookName] as $component) {
            try {
                if (!$component->isAvailable($hookName, $params)) {
                    continue;
                }
                $tmp = $component->callback($hookName, $params);
                if ($isDisplayHook) {
                    if (is_string($tmp)) {
                        $result .= $tmp;
                    }
                } elseif ($tmp !== null) {
                    $result = $tmp;
                }
            } catch (Throwable $e) {
                $this->loggerHelper->error('Error occured in hook', [
                    'hook_name' => $hookName,
                    'component' => get_class($component),
                    'exception' => $e,
                ]);
                if (!$component->catchException($hookName, $params)) {
                    throw $e;
                }
                if (
                    defined('_PS_MODE_DEV_') &&
                    _PS_MODE_DEV_
                ) {
                    throw $e;
                }
            }
        }
        return $result;
    }
    public function transformMethodToHookName(string $method): ?string
    {
        if (strpos($method, 'hook') !== 0) {
            return null;
        }
        $hookName = substr(
            $method,
            strlen('hook')
        );
        $hookName = lcfirst($hookName);
        return $hookName;
    }
    public function isDisplayHook(string $hookName): bool
    {
        $normalizedHookName = strtolower($hookName);
        return (strpos($normalizedHookName, 'display') === 0);
    }
    public function hasHook(string $hookName): bool
    {
        $components = $this->getComponents();
        return isset($components[$hookName]);
    }
    public function getHooks(): array
    {
        $components = $this->getComponents();
        return array_keys($components);
    }
    protected function getComponents(): array
    {
        static $hooks = null;
        if ($hooks === null) {
            $hooks = [];
            foreach ($this->components as $component) {
                foreach ($component::getHooks() as $hookName) {
                    if (!isset($hooks[$hookName])) {
                        $hooks[$hookName] = [];
                    }
                    $hooks[$hookName][] = $component;
                }
            }
        }
        return $hooks;
    }
}
