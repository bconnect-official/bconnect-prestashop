<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use FormField;
use IdentityController;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
use Validate;
class RemovePasswordFieldInIdentityForm implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $customerMappingRepository;
    public function __construct(
        Context $context,
        CustomerMappingRepository $customerMappingRepository
    ) {
        $this->context = $context;
        $this->customerMappingRepository = $customerMappingRepository;
    }
    public function isAvailable(string $hookName, array $params): bool
    {
        if (!($this->context->controller instanceof IdentityController)) {
            return false;
        }
        if (
            !Validate::isLoadedObject($this->context->customer) ||
            !$this->context->customer->isLogged()
        ) {
            return false;
        }
        $idCustomer = (int) $this->context->customer->id;
        $pairedCustomer = $this->customerMappingRepository->findByCustomerId($idCustomer);
        if ($pairedCustomer === null) {
            return false;
        }
        return true;
    }
    public function callback(string $hookName, array $params): void
    {
        if ($hookName === 'actionFrontControllerInitAfter') {
            $this->context->controller->passwordRequired = false;
        } elseif ($hookName === 'additionalCustomerFormFields') {
            if (
                !isset($params['fields']['new_password']) ||
                !($params['fields']['new_password'] instanceof FormField)
            ) {
                return;
            }
            $params['fields']['new_password']
                ->setType('hidden')
            ;
        }
    }
    public static function getHooks(): array
    {
        return [
            'actionFrontControllerInitAfter',
            'additionalCustomerFormFields',
        ];
    }
}
