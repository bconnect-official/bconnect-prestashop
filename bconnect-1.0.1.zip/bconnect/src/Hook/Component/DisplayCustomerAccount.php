<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Hook\Component;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Bconnect;
use Context;
use Nukium\Bconnect\Hook\HookComponentInterface;
use Nukium\Bconnect\Hook\Util\HookComponentTrait;
use Nukium\Bconnect\Repository\CustomerMappingRepository;
class DisplayCustomerAccount implements HookComponentInterface
{
    use HookComponentTrait;
    protected $context;
    protected $module;
    protected $customerMappingRepository;
    public function __construct(
        Context $context,
        Bconnect $module,
        CustomerMappingRepository $customerMappingRepository
    ) {
        $this->context = $context;
        $this->module = $module;
        $this->customerMappingRepository = $customerMappingRepository;
    }
    public function isAvailable(string $hookName, array $params): bool
    {
        return $this->context->customer->isLogged();
    }
    public function callback(string $hookName, array $params): string
    {
        $idCustomer = (int) $this->context->customer->id;
        $isPaired = $this->customerMappingRepository->findByCustomerId($idCustomer) !== null;
        return $this->module->displayHookSystem('customer_account.tpl', [
            'bconnect_is_paired' => $isPaired,
            'bconnect_module_dir' => $this->module->getPathUri(),
            'bconnect_pair_url' => $this->context->link->getModuleLink('bconnect', 'pairing'),
            'bconnect_unlink_url' => $this->context->link->getModuleLink('bconnect', 'pairing') . '?action=unlink',
            'bconnect_token' => $this->context->customer->secure_key,
        ]);
    }
    public static function getHooks(): array
    {
        return [
            'displayCustomerAccount',
        ];
    }
}
