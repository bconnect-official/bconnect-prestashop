<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Exception\ModuleException;
use PrestaShop\PrestaShop\Core\Foundation\Filesystem\FileSystem;
use Bconnect;
class FileHelper
{
    protected $module;
    public function __construct(
        Bconnect $module
    ) {
        $this->module = $module;
    }
    public function getStorageDir(?string $path = null): string
    {
        $rootDir = _PS_ROOT_DIR_;
        $result = "{$rootDir}/var/modules/{$this->module->name}";
        if ($path !== null) {
            $path = trim($path, '/');
            $result .= "/{$path}";
        }
        if (!is_dir($result)) {
            mkdir($result, FileSystem::DEFAULT_MODE_FOLDER, true);
        }
        return $result;
    }
    public function getStorageFile(string $filename): string
    {
        $simpleFilename = basename($filename);
        $path = dirname($filename);
        $path = $this->getStorageDir($path);
        return "{$path}/{$simpleFilename}";
    }
    public function exists(string $filename): bool
    {
        $path = $this->getStorageFile($filename);
        return file_exists($path);
    }
    public function read(string $filename): string
    {
        $path = $this->getStorageFile($filename);
        $content = @file_get_contents($path);
        if ($content === false) {
            throw new ModuleException("Could not read file {$path}");
        }
        return $content;
    }
    public function write(string $filename, string $content): void
    {
        $path = $this->getStorageFile($filename);
        $result = @file_put_contents($path, $content);
        if ($result === false) {
            throw new ModuleException("Could not write to file {$path}");
        }
    }
    public function delete(string $filename): void
    {
        $path = $this->getStorageFile($filename);
        $result = @unlink($path);
        if ($result === false) {
            throw new ModuleException("Could not delete file {$path}");
        }
    }
}
