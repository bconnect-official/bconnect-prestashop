<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Service\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use Nukium\Bconnect\DTO\Util\ProxyEvent;
use PrestaShop\PrestaShop\Adapter\SymfonyContainer;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface as LegacyEventDispatcherInterface;
use Symfony\Component\Finder\Finder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface;
use Throwable;
class SymfonyHelper
{
    protected $context;
    public function __construct(
        Context $context
    ) {
        $this->context = $context;
    }
    public function getCurrentRequest(): ?Request
    {
        try {
            $container = $this->getContainer();
            if ($container === null) {
                return null;
            }
            $requestStack = $container->get('request_stack');
            if (!($requestStack instanceof RequestStack)) {
                return null;
            }
            return $requestStack->getCurrentRequest();
        } catch (Throwable $e) {
            return null;
        }
    }
    public function getAllEnv(): array
    {
        $result = [];
        $rootPath = _PS_ROOT_DIR_;
        $configPath = "{$rootPath}/app/config";
        $finder = (new Finder())
            ->in($configPath)
            ->depth('== 0')
            ->name('config_*.yml')
            ->files()
        ;
        foreach ($finder as $file) {
            $filename = $file->getFilename();
            $env = str_replace('config_', '', $filename);
            $env = str_replace('.yml', '', $env);
            $result[] = $env;
        }
        return $result;
    }
    public function dispatchEvent(ProxyEvent $event): void
    {
        $container = $this->getContainer();
        if ($container === null) {
            return;
        }
        try {
            $eventDispatcher = $container->get('event_dispatcher');
        } catch (Throwable $e) {
            return;
        }
        if ($eventDispatcher instanceof EventDispatcherInterface) {
            $eventDispatcher->dispatch($event);
        } elseif ($eventDispatcher instanceof LegacyEventDispatcherInterface) {
            $eventDispatcher->dispatch(
                get_class($event),
                $event
            );
        }
    }
    public function getContainer(): ?ContainerInterface
    {
        return SymfonyContainer::getInstance();
    }
}
