<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Service\Oidc;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use Nukium\Bconnect\Value\EnvironmentValue;
use Nukium\Bconnect\Value\ScopeValue;
use Nukium\Bconnect\Vendor\Firebase\JWT\JWK;
use Nukium\Bconnect\Vendor\Firebase\JWT\JWT;
use Symfony\Contracts\HttpClient\Exception\ExceptionInterface as HttpClientExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
class OidcService
{
    const AUTHORIZE_URL_PRODUCTION = 'https://bconnect.net/a/oauth2/authorize';
    const TOKEN_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/access_token';
    const JWKS_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/connect/jwk_uri';
    const USERINFO_URL_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect/userinfo';
    const ISSUER_PRODUCTION = 'https://api.bconnect.net/sso/v2/oauth2/bconnect';
    const AUTHORIZE_URL_QUALIFICATION = 'https://bconnect-qualif.net/a/oauth2/authorize';
    const TOKEN_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/access_token';
    const JWKS_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/connect/jwk_uri';
    const USERINFO_URL_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/userinfo';
    const ISSUER_QUALIFICATION = 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect';
    const CLOCK_SKEW_LEEWAY = 60;
    const CHECK_CREDENTIALS_FAKE_CODE = 'bconnect-check-credentials';
    protected $configModuleHelper;
    protected $httpClient;
    public function __construct(
        ConfigModuleHelper $configModuleHelper,
        HttpClientInterface $httpClient
    ) {
        $this->configModuleHelper = $configModuleHelper;
        $this->httpClient = $httpClient;
    }
    public function buildAuthorizeUrl(string $state, string $nonce, string $redirectUri): string
    {
        $params = [
            'response_type' => 'code',
            'client_id' => $this->configModuleHelper->get(ConfigValue::CLIENT_ID),
            'redirect_uri' => $redirectUri,
            'scope' => $this->getScope(),
            'state' => $state,
            'nonce' => $nonce,
        ];
        $url = $this->isProduction() ? self::AUTHORIZE_URL_PRODUCTION : self::AUTHORIZE_URL_QUALIFICATION;
        return $url . '?' . http_build_query($params);
    }
    public function exchangeCode(string $code, string $redirectUri): array
    {
        $clientId = $this->configModuleHelper->get(ConfigValue::CLIENT_ID);
        $clientSecret = $this->configModuleHelper->get(ConfigValue::CLIENT_SECRET);
        $url = $this->isProduction() ? self::TOKEN_URL_PRODUCTION : self::TOKEN_URL_QUALIFICATION;
        $response = $this->httpClient->request('POST', $url, [
            'auth_basic' => [$clientId, $clientSecret],
            'body' => [
                'grant_type' => 'authorization_code',
                'code' => $code,
                'redirect_uri' => $redirectUri,
            ],
        ]);
        return $response->toArray();
    }
    public function checkCredentials(
        string $clientId,
        string $clientSecret,
        string $environment,
        string $redirectUri
    ): ?bool {
        try {
            $response = $this->httpClient->request('POST', $this->getTokenUrl($environment), [
                'auth_basic' => [$clientId, $clientSecret],
                'body' => [
                    'grant_type' => 'authorization_code',
                    'code' => self::CHECK_CREDENTIALS_FAKE_CODE,
                    'redirect_uri' => $redirectUri,
                ],
                'timeout' => 5,
            ]);
            $statusCode = $response->getStatusCode();
            $content = json_decode($response->getContent(false), true);
        } catch (HttpClientExceptionInterface $e) {
            return null;
        }
        $error = (is_array($content) && isset($content['error']))
            ? $content['error']
            : null
        ;
        if ($statusCode === 401 || $error === 'invalid_client') {
            return false;
        }
        if ($statusCode === 400 && $error === 'invalid_grant') {
            return true;
        }
        return null;
    }
    public function validateIdToken(string $idToken, string $nonce): array
    {
        $jwks = $this->fetchJwks();
        $keys = JWK::parseKeySet($jwks, 'RS256');
        JWT::$leeway = self::CLOCK_SKEW_LEEWAY;
        $decoded = JWT::decode($idToken, $keys);
        $claims = (array) $decoded;
        $clientId = $this->configModuleHelper->get(ConfigValue::CLIENT_ID);
        if (empty($claims['sub'])) {
            throw new ModuleException('[bconnect] ID Token manquant : sub');
        }
        if (empty($claims['nonce']) || $claims['nonce'] !== $nonce) {
            throw new ModuleException('[bconnect] Nonce invalide');
        }
        $aud = $claims['aud'];
        $audMatches = \is_array($aud)
            ? \in_array($clientId, $aud, true)
            : $aud === $clientId;
        if (!$audMatches) {
            throw new ModuleException('[bconnect] Audience invalide');
        }
        $expectedIss = $this->isProduction() ? self::ISSUER_PRODUCTION : self::ISSUER_QUALIFICATION;
        if (!isset($claims['iss']) || $claims['iss'] !== $expectedIss) {
            throw new ModuleException('[bconnect] Issuer invalide');
        }
        return $claims;
    }
    public function fetchUserInfo(string $accessToken): array
    {
        $url = $this->isProduction() ? self::USERINFO_URL_PRODUCTION : self::USERINFO_URL_QUALIFICATION;
        $response = $this->httpClient->request('GET', $url, [
            'auth_bearer' => $accessToken,
            'timeout' => 5,
        ]);
        return $response->toArray();
    }
    protected function getScope(): string
    {
        $scopes = $this->configModuleHelper->get(ConfigValue::SCOPES);
        if (!is_array($scopes)) {
            $scopes = [];
        }
        $scopes = array_merge(ScopeValue::MANDATORY, $scopes);
        $scopes = array_values(array_intersect(ScopeValue::ALL, $scopes));
        return implode(' ', $scopes);
    }
    protected function getTokenUrl(string $environment): string
    {
        return $environment === EnvironmentValue::PRODUCTION
            ? self::TOKEN_URL_PRODUCTION
            : self::TOKEN_URL_QUALIFICATION
        ;
    }
    protected function isProduction(): bool
    {
        return $this->configModuleHelper->get(ConfigValue::ENVIRONMENT) === EnvironmentValue::PRODUCTION;
    }
    protected function fetchJwks(): array
    {
        $url = $this->isProduction() ? self::JWKS_URL_PRODUCTION : self::JWKS_URL_QUALIFICATION;
        $response = $this->httpClient->request('GET', $url);
        return $response->toArray();
    }
}
