<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Patch;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Service\Helper\ConfigModuleHelper;
use Nukium\Bconnect\Value\ConfigValue;
use Bconnect;
class PatchSystem
{
    protected $module;
    protected $configModuleHelper;
    protected $patches;
    public function __construct(
        Bconnect $module,
        ConfigModuleHelper $configModuleHelper,
        iterable $patches
    ) {
        $this->module = $module;
        $this->configModuleHelper = $configModuleHelper;
        $this->patches = iterator_to_array($patches);
    }
    public function install(): void
    {
        $registeredPatches = $this->configModuleHelper->get(
            ConfigValue::PATCH
        );
        foreach ($this->patches as $patch) {
            $patchName = get_class($patch);
            $isAlwaysExecuted = $patch->isAlwaysExecuted();
            if (
                !$isAlwaysExecuted &&
                in_array($patchName, $registeredPatches, true)
            ) {
                continue;
            }
            $patch->install($this->module);
            if (!$isAlwaysExecuted) {
                $registeredPatches[] = $patchName;
            }
            $this->configModuleHelper->update(
                ConfigValue::PATCH,
                $registeredPatches
            );
        }
    }
    public function uninstall(): void
    {
        $registeredPatches = $this->configModuleHelper->get(
            ConfigValue::PATCH
        );
        foreach (array_reverse($this->patches) as $patch) {
            $patchName = get_class($patch);
            $patchIndex = array_search(
                $patchName,
                $registeredPatches,
                true
            );
            if (
                $patchIndex === false &&
                !$patch->isAlwaysExecuted()
            ) {
                continue;
            }
            $patch->uninstall($this->module);
            unset($registeredPatches[$patchIndex]);
            $registeredPatches = array_values($registeredPatches);
            $this->configModuleHelper->update(
                ConfigValue::PATCH,
                $registeredPatches
            );
        }
        $configs = ConfigValue::ALL;
        $configs = array_keys($configs);
        $this->configModuleHelper->deleteAll($configs);
    }
}
