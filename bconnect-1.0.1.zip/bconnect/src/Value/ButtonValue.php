<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Value;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ButtonValue
{
    public const STYLE_ICON = 'icon';
    public const STYLE_STANDARD_BLUE = 'standard_blue';
    public const STYLE_STANDARD_WHITE = 'standard_white';
    public const STYLE_CONTEXTUAL_BLUE = 'contextual_blue';
    public const STYLE_CONTEXTUAL_WHITE = 'contextual_white';
    public const STYLE_PREVIEW_IMAGES = [
        self::STYLE_ICON => 'bconnect_button.svg',
        self::STYLE_STANDARD_BLUE => 'bconnect_largebutton_blue.svg',
        self::STYLE_STANDARD_WHITE => 'bconnect_largebutton_white.svg',
        self::STYLE_CONTEXTUAL_BLUE => 'bconnect_largebutton_connect_blue.svg',
        self::STYLE_CONTEXTUAL_WHITE => 'bconnect_largebutton_connect_white.svg',
    ];
}
