<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Value;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigValue
{
    public const CONFIG_PREFIX = 'BCONNECT_';
    public const PATCH = 'PATCH';
    public const CLIENT_ID = 'CLIENT_ID';
    public const CLIENT_SECRET = 'CLIENT_SECRET';
    public const ENVIRONMENT = 'ENVIRONMENT';
    public const SCOPES = 'SCOPES';
    public const BUTTON_STYLE = 'BUTTON_STYLE';
    public const DISPLAY_SLOGAN = 'DISPLAY_SLOGAN';
    public const DEBUG_MODE = 'DEBUG_MODE';
    public const ALL = [
        self::PATCH => [
            'is_all_shop' => true,
            'init' => [],
        ],
        self::CLIENT_ID => [
            'init' => '',
        ],
        self::CLIENT_SECRET => [
            'init' => '',
        ],
        self::ENVIRONMENT => [
            'init' => EnvironmentValue::PRODUCTION,
        ],
        self::SCOPES => [
            'init' => ScopeValue::ALL,
        ],
        self::BUTTON_STYLE => [
            'init' => ButtonValue::STYLE_ICON,
        ],
        self::DISPLAY_SLOGAN => [
            'init' => true,
        ],
        self::DEBUG_MODE => [
            'is_all_shop' => true,
            'init' => false,
        ],
    ];
}
