<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Exception;
use Module;
use Nukium\Bconnect\Exception\ModuleException;
use Nukium\Bconnect\Hook\HookSystem;
use Nukium\Bconnect\Patch\PatchSystem;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Bconnect;
use ReflectionClass;
use Shop;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;
use Throwable;
use Tools;
class ModuleHelper extends Module
{
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        return
            parent::install() &&
            $this->launchPatch(true)
        ;
    }
    public function uninstall()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        return
            $this->launchPatch(false) &&
            parent::uninstall()
        ;
    }
    public function isUsingNewTranslationSystem()
    {
        return true;
    }
    public function getContent()
    {
        $originalContext = Shop::getContext();
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        $this->launchPatch(true);
        if (Shop::isFeatureActive()) {
            Shop::setContext($originalContext);
        }
        $configController = $this->context->link->getAdminLink('BconnectConfigController');
        Tools::redirectAdmin($configController);
        exit;
    }
    public function displayHookSystem(string $template, array $variables = []): string
    {
        static $modulePath = null;
        if ($modulePath === null) {
            $reflectionClass = new ReflectionClass(
                Bconnect::class
            );
            $modulePath = $reflectionClass->getFileName();
        }
        $this->context->smarty->assign($variables);
        return $this->display($modulePath, $template);
    }
    public function launchPatch(bool $install): bool
    {
        $container = new ContainerBuilder();
        $modulePath = $this->getLocalPath();
        $loader = new YamlFileLoader(
            $container,
            new FileLocator($modulePath)
        );
        $loader->load('config/patch.yml');
        $container->compile();
        $patchSystem = $container->get('nukium.bconnect.patch_system');
        $logger = $container->get('nukium.bconnect.helper.logger');
        try {
            if ($install) {
                $patchSystem->install();
            } else {
                $patchSystem->uninstall();
            }
        } catch (Exception $e) {
            $errorMessage = $e->getMessage();
            $this->_errors[] = $errorMessage;
            $logger->error("[PATCH] {$errorMessage}", [
                'exception' => $e,
            ]);
            return false;
        }
        return true;
    }
    public function getContextCacheKey(): string
    {
        return $this->getCacheId($this->name);
    }
    public function __call($method, $args)
    {
        $loggerHelper = null;
        $catch = true;
        try {
            $hookSystem = $this->get('nukium.bconnect.hook_system');
            $loggerHelper = $this->get('nukium.bconnect.helper.logger');
            if (
                !($hookSystem instanceof HookSystem) ||
                !($loggerHelper instanceof LoggerHelper)
            ) {
                throw new ModuleException('Services are not available.');
            }
            $hookName = $hookSystem->transformMethodToHookName($method);
            if ($hookName === null) {
                if (method_exists(parent::class, '__call')) {
                    return parent::__call($method, $args);
                }
                throw new ModuleException("Method \"{$method}\" not found.");
            }
            $catch = false;
            $result = $hookSystem->handle(
                $hookName,
                $args[0] ?? []
            );
            if ($result === null) {
                return;
            }
            return $result;
        } catch (Throwable $e) {
            if (!$catch) {
                throw $e;
            }
            if ($loggerHelper instanceof LoggerHelper) {
                $loggerHelper->error('Error occured in __call', [
                    'method' => $method,
                    'args' => $args,
                    'exception' => $e,
                ]);
            }
            if (
                defined('_PS_MODE_DEV_') &&
                _PS_MODE_DEV_
            ) {
                throw $e;
            }
        }
    }
}
