<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Form\Validator;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use Nukium\Bconnect\Service\Helper\LoggerHelper;
use Nukium\Bconnect\Service\Oidc\OidcService;
use Nukium\Bconnect\Value\ConfigValue;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Translation\TranslatorInterface as LegacyTranslatorInterface;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Symfony\Contracts\Translation\TranslatorInterface;
class BconnectCredentialsValidator extends ConstraintValidator
{
    private $oidcService;
    private $prestashopContext;
    private $loggerHelper;
    private $translator;
    public function __construct(
        OidcService $oidcService,
        Context $prestashopContext,
        LoggerHelper $loggerHelper,
        $translator
    ) {
        $this->oidcService = $oidcService;
        $this->prestashopContext = $prestashopContext;
        $this->loggerHelper = $loggerHelper;
        $this->translator = $translator;
    }
    public function validate($value, Constraint $constraint): void
    {
        if (!$constraint instanceof BconnectCredentials) {
            throw new UnexpectedTypeException($constraint, BconnectCredentials::class);
        }
        if (!is_array($value)) {
            return;
        }
        $clientId = isset($value[ConfigValue::CLIENT_ID]) ? (string) $value[ConfigValue::CLIENT_ID] : '';
        $clientSecret = isset($value[ConfigValue::CLIENT_SECRET]) ? (string) $value[ConfigValue::CLIENT_SECRET] : '';
        $environment = isset($value[ConfigValue::ENVIRONMENT]) ? (string) $value[ConfigValue::ENVIRONMENT] : '';
        if ($clientId === '' || $clientSecret === '') {
            return;
        }
        $isValid = $this->oidcService->checkCredentials(
            $clientId,
            $clientSecret,
            $environment,
            $this->prestashopContext->link->getModuleLink('bconnect', 'callback')
        );
        if ($isValid === null) {
            $this->loggerHelper->error('[bconnect] Impossible de vérifier les clés b.connect', [
                'environment' => $environment,
            ]);
            return;
        }
        if ($isValid === false) {
            $message = $this->translator->trans($constraint->message, [], 'Modules.Bconnect.Admin');
            $this->context->buildViolation($message)
                ->atPath('[' . ConfigValue::CLIENT_SECRET . ']')
                ->addViolation()
            ;
        }
    }
}
