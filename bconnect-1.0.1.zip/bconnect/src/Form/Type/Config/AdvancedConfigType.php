<?php
/**
 * Module developed by Nukium
 *
 * @author    Nukium SAS
 * @copyright 2023-2026 Nukium SAS
 * @license   Proprietary - All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * PROPRIETARY AND CONFIDENTIAL SOFTWARE
 * Copyright (c) Nukium SAS. All rights reserved.
 *
 * This software, including its source code, is proprietary to Nukium
 * SAS and is protected by French and international copyright laws.
 *
 * Use of this software is permitted only within the scope of the
 * rights expressly granted by Nukium SAS or an applicable agreement.
 * No transfer of intellectual property rights is implied.
 *
 * Without prior written authorization from Nukium SAS, the following
 * actions are prohibited:
 *
 * - Modification, adaptation or creation of derivative works.
 * - Reproduction or reuse beyond the authorized scope of use.
 * - Redistribution, publication, sublicensing or transfer.
 * - Resale or independent commercial exploitation of the software.
 * - Disclosure or provision of source code to unauthorized third
 *   parties, including external AI services or coding agents.
 *
 * These restrictions apply whether the actions are performed
 * manually, automatically or using artificial intelligence.
 *
 * All restrictions are subject to mandatory applicable law,
 * including the statutory rights of lawful software users, and
 * to any applicable third-party licenses.
 */

namespace Nukium\Bconnect\Form\Type\Config;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Nukium\Bconnect\Form\EventListener\ConfigurationDataListener;
use Nukium\Bconnect\Form\Type\Util\AdminLinkType;
use Nukium\Bconnect\Value\ConfigValue;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\FormBuilderInterface;
class AdvancedConfigType extends TranslatorAwareType
{
    protected $configurationDataListener;
    public function __construct(
        $translator,
        array $locales,
        ConfigurationDataListener $configurationDataListener
    ) {
        parent::__construct(
            $translator,
            $locales
        );
        $this->configurationDataListener = $configurationDataListener;
    }
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        parent::buildForm($builder, $options);
        $builder
            ->add(ConfigValue::DEBUG_MODE, SwitchType::class, [
                'label' => $this->trans('Enable debug mode', 'Modules.Bconnect.Admin'),
                'help' => $this->trans(
                    'Silently logs more detailed information useful for debugging.',
                    'Modules.Bconnect.Admin'
                ),
                'required' => false,
            ])
            ->add('DOWNLOAD_ERROR_LOG', AdminLinkType::class, [
                'label' => $this->trans('Error log', 'Modules.Bconnect.Admin'),
                'button_label' => $this->trans("Download today's error log", 'Modules.Bconnect.Admin'),
                'route' => 'bconnect_config_download_log',
                'route_parameters' => ['type' => 'error'],
            ])
            ->add('DOWNLOAD_DEBUG_LOG', AdminLinkType::class, [
                'label' => $this->trans('Debug log', 'Modules.Bconnect.Admin'),
                'button_label' => $this->trans("Download today's debug log", 'Modules.Bconnect.Admin'),
                'route' => 'bconnect_config_download_log',
                'route_parameters' => ['type' => 'debug'],
            ])
            ->addEventSubscriber($this->configurationDataListener)
        ;
    }
}
