{*
* Module developed by Nukium
*
* @author    Nukium SAS
* @copyright 2023-2026 Nukium SAS
* @license   Proprietary - All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* PROPRIETARY AND CONFIDENTIAL SOFTWARE
* Copyright (c) Nukium SAS. All rights reserved.
*
* This software, including its source code, is proprietary to Nukium
* SAS and is protected by French and international copyright laws.
*
* Use of this software is permitted only within the scope of the
* rights expressly granted by Nukium SAS or an applicable agreement.
* No transfer of intellectual property rights is implied.
*
* Without prior written authorization from Nukium SAS, the following
* actions are prohibited:
*
* - Modification, adaptation or creation of derivative works.
* - Reproduction or reuse beyond the authorized scope of use.
* - Redistribution, publication, sublicensing or transfer.
* - Resale or independent commercial exploitation of the software.
* - Disclosure or provision of source code to unauthorized third
*   parties, including external AI services or coding agents.
*
* These restrictions apply whether the actions are performed
* manually, automatically or using artificial intelligence.
*
* All restrictions are subject to mandatory applicable law,
* including the statutory rights of lawful software users, and
* to any applicable third-party licenses.
*}
<div
    class="modal fade bconnect-modal"
    id="bconnect-informations-modal"
    tabindex="-1"
    role="dialog"
    aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content bconnect-modal__content">
            <div class="modal-body">
                <button
                    type="button"
                    class="bconnect-modal__close btn-close"
                    data-dismiss="modal"
                    data-bs-dismiss="modal"
                    aria-label="{l s='Close' d='Modules.Bconnect.Shop'}"
                ></button>
                <iframe
                    src="https://www.bconnect.net/modale/fr/modale.htm"
                    class="bconnect-modal__iframe"
                    title="{l s='b.connect information' d='Modules.Bconnect.Shop'}"
                    loading="lazy"
                    frameborder="0"
                ></iframe>
            </div>
        </div>
    </div>
</div>
