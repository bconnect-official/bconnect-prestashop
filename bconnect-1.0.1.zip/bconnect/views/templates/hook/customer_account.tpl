{*
* Module developed by Nukium
*
* @author    Nukium SAS
* @copyright 2023-2026 Nukium SAS
* @license   Proprietary - All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* PROPRIETARY AND CONFIDENTIAL SOFTWARE
* Copyright (c) Nukium SAS. All rights reserved.
*
* This software, including its source code, is proprietary to Nukium
* SAS and is protected by French and international copyright laws.
*
* Use of this software is permitted only within the scope of the
* rights expressly granted by Nukium SAS or an applicable agreement.
* No transfer of intellectual property rights is implied.
*
* Without prior written authorization from Nukium SAS, the following
* actions are prohibited:
*
* - Modification, adaptation or creation of derivative works.
* - Reproduction or reuse beyond the authorized scope of use.
* - Redistribution, publication, sublicensing or transfer.
* - Resale or independent commercial exploitation of the software.
* - Disclosure or provision of source code to unauthorized third
*   parties, including external AI services or coding agents.
*
* These restrictions apply whether the actions are performed
* manually, automatically or using artificial intelligence.
*
* All restrictions are subject to mandatory applicable law,
* including the statutory rights of lawful software users, and
* to any applicable third-party licenses.
*}
{* Variante sidebar (account-menu--sidebar) : lien simple vers le compte client *}
<a class="account-menu__link bconnect-account-block--sidebar" id="bconnect_sidebar_link" href="{$urls.pages.my_account|escape:'html':'UTF-8'}">
    <div class="bconnect-account-block__logo">
        <img
            src="{$bconnect_module_dir|escape:'html':'UTF-8'}views/img/bconnect_button.svg"
            alt="b.connect"
            class="bconnect-account-block__icon"
        />
        <span class="bconnect-account-block__title">{l s='b.connect' d='Modules.Bconnect.Shop'}</span>
    </div>
</a>

{* Variante grille principale (account-menu--main) : bloc complet de liaison *}
<div class="account-menu__link bconnect-account-block--main">
    <div class="bconnect-account-block">
        <div class="bconnect-account-block__logo">
            <img
                src="{$bconnect_module_dir|escape:'html':'UTF-8'}views/img/bconnect_button.svg"
                alt="b.connect"
                class="bconnect-account-block__icon"
            />
            <span class="bconnect-account-block__title">{l s='b.connect' d='Modules.Bconnect.Shop'}</span>
        </div>

        {if $bconnect_is_paired}
            <p class="bconnect-account-block__status bconnect-account-block__status--linked">
                {l s='Your account is linked to b.connect.' d='Modules.Bconnect.Shop'}
            </p>
            <form action="{$bconnect_unlink_url|escape:'html':'UTF-8'}" method="post" class="bconnect-account-block__form">
                <input type="hidden" name="action" value="unlink" />
                <input type="hidden" name="token" value="{$bconnect_token|escape:'html':'UTF-8'}" />
                <button type="submit" class="bconnect-account-block__btn bconnect-account-block__btn--unlink btn btn-secondary">
                    {l s='Unlink b.connect' d='Modules.Bconnect.Shop'}
                </button>
            </form>
        {else}
            <p class="bconnect-account-block__status">
                {l s='Link your account to sign in quickly with b.connect.' d='Modules.Bconnect.Shop'}
            </p>
            <form action="{$bconnect_pair_url|escape:'html':'UTF-8'}" method="post" class="bconnect-account-block__form">
                <button type="submit" class="bconnect-account-block__btn bconnect-account-block__btn--link btn btn-primary btn-sm">
                    {l s='Link my b.connect account' d='Modules.Bconnect.Shop'}
                </button>
            </form>
        {/if}
    </div>
</div>
