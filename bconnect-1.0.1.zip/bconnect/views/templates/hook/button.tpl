{*
* Module developed by Nukium
*
* @author    Nukium SAS
* @copyright 2023-2026 Nukium SAS
* @license   Proprietary - All rights reserved
*
* ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
* ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
* ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
* ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
* ██   ████  ██████  ██   ██ ██  ██████  ██      ██
*
* PROPRIETARY AND CONFIDENTIAL SOFTWARE
* Copyright (c) Nukium SAS. All rights reserved.
*
* This software, including its source code, is proprietary to Nukium
* SAS and is protected by French and international copyright laws.
*
* Use of this software is permitted only within the scope of the
* rights expressly granted by Nukium SAS or an applicable agreement.
* No transfer of intellectual property rights is implied.
*
* Without prior written authorization from Nukium SAS, the following
* actions are prohibited:
*
* - Modification, adaptation or creation of derivative works.
* - Reproduction or reuse beyond the authorized scope of use.
* - Redistribution, publication, sublicensing or transfer.
* - Resale or independent commercial exploitation of the software.
* - Disclosure or provision of source code to unauthorized third
*   parties, including external AI services or coding agents.
*
* These restrictions apply whether the actions are performed
* manually, automatically or using artificial intelligence.
*
* All restrictions are subject to mandatory applicable law,
* including the statutory rights of lawful software users, and
* to any applicable third-party licenses.
*}
<div class="bconnect-btn-wrapper">
    {capture name='bconnect_separator'}
        <div class="bconnect-separator">
            <span>{l s='or' d='Modules.Bconnect.Shop'}</span>
        </div>
    {/capture}
    {assign var='bconnect_context' value=($bconnect_variant == 'create') ? 'create' : 'connect'}
    {if $bconnect_context == 'create'}
        {assign var='bconnect_text_alt' value={l s='Create with b.connect' d='Modules.Bconnect.Shop'}}
    {else}
        {assign var='bconnect_text_alt' value={l s='Sign in with b.connect' d='Modules.Bconnect.Shop'}}
        {$smarty.capture.bconnect_separator nofilter}
    {/if}
    {if $bconnect_display_slogan}
        <div class="bconnect-slogan">
            <p>
                {l s='Simplify and secure your logins with b.connect, the free, sovereign passwordless solution backed by France\'s largest banks.' d='Modules.Bconnect.Shop'}
                <br>
                <a
                    href="#"
                    class="bconnect-informations-link"
                    data-toggle="modal"
                    data-target="#bconnect-informations-modal"
                    data-bs-toggle="modal"
                    data-bs-target="#bconnect-informations-modal"
                >
                    {l s='Learn more' d='Modules.Bconnect.Shop'}
                </a>
            </p>
        </div>
    {/if}
    {assign var='bconnect_color' value=($bconnect_style == 'standard_white' || $bconnect_style == 'contextual_white') ? 'white' : 'blue'}
    {if empty($bconnect_force_variant) && $bconnect_style == 'icon'}
        {assign var='bconnect_img' value='bconnect_button.svg'}
        {assign var='bconnect_alt' value='b.connect'}
    {elseif empty($bconnect_force_variant) && ($bconnect_style == 'standard_blue' || $bconnect_style == 'standard_white')}
        {assign var='bconnect_img' value="bconnect_largebutton_{$bconnect_color}.svg"}
        {assign var='bconnect_alt' value='b.connect'}
    {else}
        {assign var='bconnect_img' value="bconnect_largebutton_{$bconnect_context}_{$bconnect_color}.svg"}
        {assign var='bconnect_alt' value=$bconnect_text_alt}
    {/if}
    <a
        href="{$bconnect_authorize_url|escape:'html':'UTF-8'}"
        class="bconnect-btn"
        aria-label="{$bconnect_alt|escape:'html':'UTF-8'}"
    >
        <img
            src="{$bconnect_module_dir|escape:'html':'UTF-8'}views/img/{$bconnect_img|escape:'html':'UTF-8'}"
            alt="{$bconnect_alt|escape:'html':'UTF-8'}"
            class="bconnect-btn__img"
            loading="lazy"
            decoding="async"
            height="42"
            width="300"
        />
    </a>
    {if $bconnect_context == 'create'}
        {$smarty.capture.bconnect_separator nofilter}
    {/if}
</div>
